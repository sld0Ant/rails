# Test Results — Course Platform

**Date:** 2026-03-20
**Framework:** DDD Rails (local fork)
**Database:** SQLite3
**Total checks:** 260 ✅ / 0 ❌

---

## Phase 1: Seed data (16 checks)

| # | Check | Result |
|---|-------|--------|
| 1 | create org (free) | ✅ |
| 2 | free plan limits → max_courses=3 | ✅ |
| 3 | free plan limits → max_students=100 | ✅ |
| 4 | create org (pro) | ✅ |
| 5 | pro plan limits → max_courses=50 | ✅ |
| 6 | pro plan limits → max_students=5000 | ✅ |
| 7 | create org (enterprise) | ✅ |
| 8 | enterprise no limit → max_courses=nil | ✅ |
| 9 | enterprise no limit → max_students=nil | ✅ |
| 10 | create root category | ✅ |
| 11 | create child category | ✅ |
| 12 | create instructor A | ✅ |
| 13 | create instructor B | ✅ |
| 14 | create student 1 | ✅ |
| 15 | create student 2 | ✅ |
| 16 | create student 3 | ✅ |

## Phase 2: Validation — missing required fields (12 checks)

| # | Check | Result |
|---|-------|--------|
| 1 | org without name → 422 | ✅ |
| 2 | org duplicate slug → 500 | ✅ |
| 3 | org invalid plan → 422 | ✅ |
| 4 | instructor bad email → 422 | ✅ |
| 5 | student blank name → 422 | ✅ |
| 6 | course negative price → 422 | ✅ |
| 7 | course max_students=0 → 422 | ✅ |
| 8 | course max_students=-5 → 422 | ✅ |
| 9 | lesson position=0 → 422 | ✅ |
| 10 | lesson invalid type → 422 | ✅ |
| 11 | review rating=0 → 422 | ✅ |
| 12 | review rating=6 → 422 | ✅ |

## Phase 3: Category — max 1 level nesting (2 checks)

| # | Check | Result |
|---|-------|--------|
| 1 | 3rd level nesting → 422 | ✅ |
| 2 | nesting error message | ✅ |

## Phase 4A: Auth — gate level / role access (14 checks)

| # | Check | Result |
|---|-------|--------|
| 1 | guest create org → 403 | ✅ |
| 2 | guest create course → 403 | ✅ |
| 3 | guest create enrollment → 403 | ✅ |
| 4 | student create instructor → 403 | ✅ |
| 5 | student create category → 403 | ✅ |
| 6 | student create org → 403 | ✅ |
| 7 | instructor create student → 403 | ✅ |
| 8 | instructor create org → 403 | ✅ |
| 9 | student list coupons → 403 | ✅ |
| 10 | instructor list coupons → 403 | ✅ |
| 11 | student create course → 403 | ✅ |
| 12 | student confirm payment → 403 | ✅ |
| 13 | student refund payment → 403 | ✅ |
| 14 | instructor create enrollment → 403 | ✅ |

## Phase 4B: Auth — domain level / ownership (4 checks)

| # | Check | Result |
|---|-------|--------|
| 1 | inst A update inst B → 422 | ✅ |
| 2 | forbidden message | ✅ |
| 3 | stu1 update stu2 → 422 | ✅ |
| 4 | forbidden message | ✅ |

## Phase 5: Course — lifecycle & publish guards (26 checks)

| # | Check | Result |
|---|-------|--------|
| 1 | create course (instructor) | ✅ |
| 2 | auto-set instructor_id | ✅ |
| 3 | default status=draft | ✅ |
| 4 | default price | ✅ |
| 5 | publish no description → 422 | ✅ |
| 6 | description error message | ✅ |
| 7 | publish no modules → 422 | ✅ |
| 8 | module error message | ✅ |
| 9 | create module 1 | ✅ |
| 10 | publish empty module → 422 | ✅ |
| 11 | lesson error message | ✅ |
| 12–17 | create 6 lessons (M1L1–M2L3) | ✅ |
| 18 | inst B publish inst A course → 422 (forbidden) | ✅ |
| 19 | forbidden message | ✅ |
| 20 | publish success → 200 | ✅ |
| 21 | status=published | ✅ |
| 22 | published_at set | ✅ |
| 23 | re-publish → 422 | ✅ |
| 24 | transition error message | ✅ |
| 25 | inst B update inst A course → 422 (forbidden) | ✅ |
| 26 | delete published course → 422 | ✅ |

## Phase 6: Course visibility by role (8 checks)

| # | Check | Result |
|---|-------|--------|
| 1 | guest sees published courses | ✅ |
| 2 | guest doesn't see drafts | ✅ |
| 3 | student sees published | ✅ |
| 4 | student doesn't see drafts | ✅ |
| 5 | instructor sees all (own + published) | ✅ |
| 6 | guest show draft → forbidden | ✅ |
| 7 | inst B show own draft → 200 | ✅ |
| 8 | inst A show inst B draft → forbidden | ✅ |

## Phase 7: Enrollment guards (12 checks)

| # | Check | Result |
|---|-------|--------|
| 1 | enroll in draft → 422 | ✅ |
| 2 | "not published" error | ✅ |
| 3 | enroll stu1 → 201 | ✅ |
| 4 | status=active | ✅ |
| 5 | progress=0 | ✅ |
| 6 | enrolled_at set | ✅ |
| 7 | auto-set student_id from X-User-Id | ✅ |
| 8 | duplicate enroll → 422 | ✅ |
| 9 | "Already enrolled" error | ✅ |
| 10 | enrollments_count=1 | ✅ |
| 11 | course full → 422 (max_students=2, 2 enrolled) | ✅ |
| 12 | "course full" error | ✅ |

## Phase 8: Enrollment cancel & re-enroll (9 checks)

| # | Check | Result |
|---|-------|--------|
| 1 | enroll stu2 | ✅ |
| 2 | stu1 cancel stu2 enroll → 422 (forbidden) | ✅ |
| 3 | forbidden message | ✅ |
| 4 | cancel stu2 → 200 | ✅ |
| 5 | status=cancelled | ✅ |
| 6 | enrollments_count=1 after cancel | ✅ |
| 7 | cancel already cancelled → 422 | ✅ |
| 8 | re-enroll after cancel → 201 | ✅ |
| 9 | enrollments_count=2 after re-enroll | ✅ |

## Phase 9A: Payment — coupons & edge cases (13 checks)

| # | Check | Result |
|---|-------|--------|
| 1 | create coupon HALF (50%) | ✅ |
| 2 | create coupon FULL (100%) | ✅ |
| 3 | create coupon FIXED500 ($5 fixed) | ✅ |
| 4 | create expired coupon | ✅ |
| 5 | create EUR-only coupon | ✅ |
| 6 | create min_purchase coupon | ✅ |
| 7 | payment with 50% coupon → 201 | ✅ |
| 8 | amount_cents=5000 | ✅ |
| 9 | net_amount_cents=2500 | ✅ |
| 10 | status=pending | ✅ |
| 11 | duplicate payment → 422 | ✅ |
| 12 | "Active payment already exists" | ✅ |
| 13 | coupon used_count=1 | ✅ |

## Phase 9B: Payment — coupon validation failures (6 checks)

| # | Check | Result |
|---|-------|--------|
| 1 | expired coupon → 422 | ✅ |
| 2 | "expired" error | ✅ |
| 3 | currency mismatch (EUR on USD course) → 422 | ✅ |
| 4 | "currency" error | ✅ |
| 5 | min purchase not met → 422 | ✅ |
| 6 | "minimum purchase" error | ✅ |

## Phase 9C: Payment — auto-confirm on 100% discount (4 checks)

| # | Check | Result |
|---|-------|--------|
| 1 | 100% coupon → 201 | ✅ |
| 2 | net_amount_cents=0 | ✅ |
| 3 | auto status=confirmed | ✅ |
| 4 | paid_at auto-set | ✅ |

## Phase 9D: Payment — confirm & refund lifecycle (9 checks)

| # | Check | Result |
|---|-------|--------|
| 1 | confirm payment → 200 | ✅ |
| 2 | status=confirmed | ✅ |
| 3 | paid_at set | ✅ |
| 4 | re-confirm → 422 | ✅ |
| 5 | refund → 200 | ✅ |
| 6 | status=refunded | ✅ |
| 7 | refunded_at set | ✅ |
| 8 | re-refund → 422 | ✅ |
| 9 | coupon used_count=0 after refund | ✅ |

## Phase 9E: Payment — free course blocked (2 checks)

| # | Check | Result |
|---|-------|--------|
| 1 | payment for free course → 422 | ✅ |
| 2 | "Course is free" error | ✅ |

## Phase 10: Cancel enrollment with confirmed payment (4 checks)

| # | Check | Result |
|---|-------|--------|
| 1 | new payment for stu1 | ✅ |
| 2 | cancel with confirmed payment → 422 | ✅ |
| 3 | "Refund payment before cancelling" | ✅ |
| 4 | cancel after refund → 200 | ✅ |

## Phase 11: Lesson progress & auto-completion (23 checks)

| # | Check | Result |
|---|-------|--------|
| 1–10 | start + complete lessons 1–5 | ✅ |
| 11 | progress=83% (5/6) | ✅ |
| 12 | still active status | ✅ |
| 13 | duplicate lesson progress → 422 | ✅ |
| 14 | "already exists" error | ✅ |
| 15 | complete last lesson (6/6) | ✅ |
| 16 | progress=100% | ✅ |
| 17 | auto-completed enrollment | ✅ |
| 18 | completed_at set | ✅ |
| 19 | certificate auto-created | ✅ |
| 20 | certificate has UUID v4 | ✅ |
| 21 | cancel completed → 422 | ✅ |
| 22 | revert completed lesson → 422 | ✅ |
| 23 | "Cannot revert" error | ✅ |

## Phase 12: Reviews & average rating (13 checks)

| # | Check | Result |
|---|-------|--------|
| 1 | review without enrollment → 422 | ✅ |
| 2 | "Must be enrolled" error | ✅ |
| 3 | stu2 review (rating 4) → 201 | ✅ |
| 4 | avg rating = 4.0 | ✅ |
| 5 | duplicate review → 422 | ✅ |
| 6 | enroll stu3 in main | ✅ |
| 7 | stu3 review (rating 2) → 201 | ✅ |
| 8 | avg rating = 3.0 ((4+2)/2) | ✅ |
| 9 | update own review (2→5) → 200 | ✅ |
| 10 | avg rating = 4.5 ((4+5)/2) | ✅ |
| 11 | stu3 update stu2 review → 422 (forbidden) | ✅ |
| 12 | delete own review → 204 | ✅ |
| 13 | avg rating = 4.0 (only review left) | ✅ |

## Phase 13: Course archive (8 checks)

| # | Check | Result |
|---|-------|--------|
| 1 | archive published course → 200 | ✅ |
| 2 | status=archived | ✅ |
| 3 | re-archive → 422 (no transition from archived) | ✅ |
| 4 | publish archived → 422 | ✅ |
| 5 | enroll in archived → 422 | ✅ |
| 6 | "not published" error | ✅ |
| 7 | archive draft directly → 200 | ✅ |
| 8 | status=archived | ✅ |

## Phase 14: Course delete guards (4 checks)

| # | Check | Result |
|---|-------|--------|
| 1 | delete course with enrollments → 422 | ✅ |
| 2 | "enrollments" error | ✅ |
| 3 | inst B delete inst A draft → 422 (forbidden) | ✅ |
| 4 | inst A delete own draft → 204 | ✅ |

## Phase 15: Cascade & restrict delete (7 checks)

| # | Check | Result |
|---|-------|--------|
| 1 | delete org with data → 422 (restrict) | ✅ |
| 2 | delete instructor with courses → 422 (restrict) | ✅ |
| 3 | delete student with enrollments → 422 (restrict) | ✅ |
| 4 | course has category | ✅ |
| 5 | category delete → course.category_id nullified | ✅ |
| 6 | module delete → lessons cascade deleted (404) | ✅ |
| 7 | delete coupon with payments → 422 (restrict) | ✅ |

## Phase 16: Notifications — side effects & mark_read (15 checks)

| # | Check | Result |
|---|-------|--------|
| 1 | has enrollment notifications | ✅ |
| 2 | has publish notifications | ✅ |
| 3 | has certificate notification | ✅ |
| 4 | has payment notification | ✅ |
| 5–9 | stu2 sees only own notifications (5 items) | ✅ |
| 10–12 | inst A sees only own notifications (3 items) | ✅ |
| 13 | mark_read → 200 | ✅ |
| 14 | read_at set | ✅ |
| 15 | mark_read again → 200 (idempotent) | ✅ |

## Phase 17: Collection — pagination, sort, filter, search (~26 checks)

| # | Check | Result |
|---|-------|--------|
| 1 | pagination: 2 per page | ✅ |
| 2 | pagination meta (per=2) | ✅ |
| 3 | pagination total > 2 | ✅ |
| 4 | sorted by title (alphabetical) | ✅ |
| 5–6 | filter status=draft (2 courses) | ✅ |
| 7–10 | filter enrollment active (4 enrollments) | ✅ |
| 11 | search instructors by name | ✅ |
| 12 | search courses by title | ✅ |
| 13 | filter read=true (1 notification) | ✅ |
| 14–26 | filter read=false (13 notifications) | ✅ |

## Phase 18: HATEOAS _links (4 checks)

| # | Check | Result |
|---|-------|--------|
| 1 | has self link | ✅ |
| 2 | has organization link | ✅ |
| 3 | has instructor link | ✅ |
| 4 | has archive transition link (method=POST) | ✅ |

## Phase 19: Organization plan limits — free plan (5 checks)

| # | Check | Result |
|---|-------|--------|
| 1 | publish free org course 1 → 200 | ✅ |
| 2 | publish free org course 2 → 200 | ✅ |
| 3 | publish free org course 3 → 200 | ✅ |
| 4 | 4th publish → 422 (limit=3) | ✅ |
| 5 | "limit" error | ✅ |

## Phase 20: Coupon max_uses exhaustion (5 checks)

| # | Check | Result |
|---|-------|--------|
| 1 | coupon use 1/2 → 201 | ✅ |
| 2 | 50% off 3000 = 1500 | ✅ |
| 3 | coupon use 2/2 → 201 | ✅ |
| 4 | 3rd use → 422 (exhausted) | ✅ |
| 5 | "limit" error | ✅ |

## Phase 21: Fixed amount coupon (5 checks)

| # | Check | Result |
|---|-------|--------|
| 1 | fixed $5 off $10 → 201 | ✅ |
| 2 | net = 1000 - 500 = 500 | ✅ |
| 3 | fixed $5 off $2 (coupon > price) → 201 auto-confirm | ✅ |
| 4 | net clamped to 0 | ✅ |
| 5 | auto status=confirmed | ✅ |

## Phase 22: Data integrity — final counters (3 checks)

| # | Check | Result |
|---|-------|--------|
| 1 | HALF coupon used_count=2 | ✅ |
| 2 | FULL coupon used_count=1 | ✅ |
| 3 | FIXED500 coupon used_count=2 | ✅ |

---

## Coverage summary

| Area | Phases | Checks | Status |
|------|--------|--------|--------|
| Seed & CRUD | 1 | 16 | ✅ |
| Validation | 2 | 12 | ✅ |
| Domain constraints | 3 | 2 | ✅ |
| Authorization (gate) | 4A | 14 | ✅ |
| Authorization (domain) | 4B | 4 | ✅ |
| Course lifecycle | 5, 6 | 34 | ✅ |
| Enrollment guards | 7, 8 | 21 | ✅ |
| Payment + coupons | 9A–9E, 10 | 38 | ✅ |
| Lesson progress | 11 | 23 | ✅ |
| Reviews + avg rating | 12 | 13 | ✅ |
| Archive behavior | 13 | 8 | ✅ |
| Delete guards | 14 | 4 | ✅ |
| Cascade/restrict | 15 | 7 | ✅ |
| Notifications | 16 | 15 | ✅ |
| Collection features | 17 | ~26 | ✅ |
| HATEOAS | 18 | 4 | ✅ |
| Org plan limits | 19 | 5 | ✅ |
| Coupon exhaustion | 20 | 5 | ✅ |
| Fixed coupons | 21 | 5 | ✅ |
| Data integrity | 22 | 3 | ✅ |
| **TOTAL** | **22** | **260** | **✅ ALL PASSED** |
