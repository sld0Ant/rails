# Enrollment — Behavioral Spec

## Contracts

  invariant: course_id present
  invariant: student_id present
  invariant: status in %w[active completed cancelled]
  invariant: progress_percent 0..100, readonly
  invariant: enrolled_at readonly
  invariant: completed_at readonly, nullable

  # Create
  pre:  course.status == "published"
  pre:  no active/completed enrollment for same course+student (cancelled ok)
  pre:  course not full (enrollments_count < max_students if set)
  pre:  org not over max_students (unique students)
  post: status = "active", progress_percent = 0
  post: enrolled_at = Time.current
  post: course.enrollments_count += 1 (atomic SQL)

  # Cancel
  pre:  status == "active" (completed cannot be cancelled)
  pre:  no confirmed payment (must refund first)
  post: status = "cancelled"
  post: course.enrollments_count -= 1 (atomic SQL)

  # Complete (automatic)
  pre:  progress_percent == 100
  post: status = "completed", completed_at = Time.current
  post: certificate created automatically
  post: notification to student

## Authorization

| Action   | admin | instructor   | student | guest |
|----------|-------|--------------|---------|-------|
| index    | ✓     | own courses  | own     | ✗     |
| show     | ✓     | own courses  | own     | ✗     |
| create   | ✓     | ✗            | ✓       | ✗     |
| cancel   | ✓     | ✗            | own     | ✗     |

No update. No destroy (use cancel).

## Lifecycle

  [active] --complete--> [completed]
  [active] --cancel--> [cancelled]

  complete: automatic, triggered by progress_percent == 100
  cancel: manual by student or admin

  completed and cancelled are final.

## Scenarios

  Given course in draft
  When student creates enrollment
  Then 422, "Course is not published"

  Given student already has active enrollment on course
  When student creates enrollment
  Then 422, "Already enrolled"

  Given student has cancelled enrollment on course
  When student creates enrollment
  Then 201 (re-enroll allowed)

  Given course with max_students: 2, enrollments_count: 2
  When student creates enrollment
  Then 422, "Course is full"

  Given enrollment with confirmed payment
  When student cancels enrollment
  Then 422, "Refund payment before cancelling"

  Given completed enrollment
  When student cancels
  Then 422, "Cannot cancel completed enrollment"

## Side Effects

  @on(create): notification to student, event: "enrollment",
               title: "Enrolled in {course.title}"
  @on(create): course.enrollments_count += 1
  @on(cancel): course.enrollments_count -= 1
  @on(complete): certificate created, notification to student
