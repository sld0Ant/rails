# Course — Behavioral Spec

## Contracts

  invariant: title present
  invariant: organization_id present
  invariant: instructor_id present
  invariant: price_cents >= 0
  invariant: currency present (default "USD")
  invariant: max_students > 0 if present
  invariant: status in %w[draft published archived]
  invariant: enrollments_count >= 0, readonly
  invariant: average_rating readonly, nullable
  invariant: published_at readonly, nullable

  # Create (instructor role)
  post: instructor_id auto-set to X-User-Id

  # Publish
  pre:  description present
  pre:  at least 1 Module
  pre:  each Module has at least 1 Lesson
  pre:  org published courses < org.max_courses (if max_courses set)
  post: published_at = Time.current
  post: status = "published"

  # Archive
  pre:  status in [draft, published]
  post: status = "archived"
  post: existing active enrollments stay (students finish)
  post: new enrollments blocked

  # Destroy
  pre:  no enrollments of any status
  pre:  instructor can only destroy own draft

## Authorization

| Action   | admin | instructor       | student   | guest     |
|----------|-------|------------------|-----------|-----------|
| index    | ✓     | ✓                | published | published |
| show     | ✓     | own OR published | published | published |
| create   | ✓     | ✓                | ✗         | ✗         |
| update   | ✓     | own              | ✗         | ✗         |
| destroy  | ✓     | own AND draft    | ✗         | ✗         |
| publish  | ✓     | own              | ✗         | ✗         |
| archive  | ✓     | own              | ✗         | ✗         |

## Lifecycle

  [draft] --publish--> [published] --archive--> [archived]
    \                                             /
     `--archive--> [archived]

  publish: draft → published
  archive: draft|published → archived
  No return from archived.

## Scenarios

  Given course in draft, no description
  When instructor calls POST /courses/:id/publish
  Then 422, errors: ["Description can't be blank"]

  Given course in draft, description present, 0 modules
  When instructor calls POST /courses/:id/publish
  Then 422, errors: ["At least one module required"]

  Given course in draft, 1 module with 0 lessons
  When instructor calls POST /courses/:id/publish
  Then 422, errors: ["Each module must have at least one lesson"]

  Given org plan free (max_courses: 3), already 3 published courses
  When instructor calls POST /courses/:id/publish
  Then 422, errors: ["Organization course limit reached"]

  Given course with 1 enrollment
  When admin calls DELETE /courses/:id
  Then 422, errors: ["Cannot delete course with enrollments"]

  Given course in published status
  When instructor calls DELETE /courses/:id
  Then 422, errors: ["Can only delete draft courses"]

## Side Effects

  @on(publish): notification to instructor, event: "publish",
                title: "Course {course.title} published"
