# Organization — Behavioral Spec

## Contracts

  invariant: name present
  invariant: slug present, unique
  invariant: plan in %w[free pro enterprise]
  invariant: max_courses >= 0 if present
  invariant: max_students >= 0 if present

  # Create
  post: max_courses and max_students auto-set by plan:
        free → 3/100, pro → 50/5000, enterprise → nil/nil
        admin can override after creation

## Authorization

| Action   | admin | instructor | student  | guest |
|----------|-------|------------|----------|-------|
| index    | ✓     | ✗          | ✗        | ✗     |
| show     | ✓     | own org    | own org  | ✗     |
| create   | ✓     | ✗          | ✗        | ✗     |
| update   | ✓     | ✗          | ✗        | ✗     |
| destroy  | ✓     | ✗          | ✗        | ✗     |

## Scenarios

  Given organization with 2 courses, 1 instructor
  When admin calls DELETE /organizations/:id
  Then 422, errors: ["Cannot delete organization with existing courses/instructors/students"]

  Given organization plan "pro"
  When admin creates organization
  Then max_courses = 50, max_students = 5000
