# Lesson — Behavioral Spec

## Contracts

  invariant: title present
  invariant: module_id present
  invariant: lesson_type in %w[video text quiz], default "text"
  invariant: position >= 1
  invariant: duration_minutes > 0 if present

## Authorization

| Action   | admin | instructor  | student  | guest     |
|----------|-------|-------------|----------|-----------|
| index    | ✓     | ✓           | enrolled | published |
| show     | ✓     | ✓           | enrolled | published |
| create   | ✓     | own course  | ✗        | ✗         |
| update   | ✓     | own course  | ✗        | ✗         |
| destroy  | ✓     | own course  | ✗        | ✗         |
