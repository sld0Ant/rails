# Coupon — Behavioral Spec

## Contracts

  invariant: code present, unique
  invariant: discount_type in %w[percent fixed]
  invariant: discount_value > 0
  invariant: discount_value 1..100 when discount_type == "percent"
  invariant: currency required when discount_type == "fixed"
  invariant: starts_at present
  invariant: expires_at present
  invariant: used_count >= 0, readonly

## Authorization

| Action   | admin | instructor | student | guest |
|----------|-------|------------|---------|-------|
| index    | ✓     | ✗          | ✗       | ✗     |
| show     | ✓     | ✗          | ✗       | ✗     |
| create   | ✓     | ✗          | ✗       | ✗     |
| update   | ✓     | ✗          | ✗       | ✗     |
| destroy  | ✓     | ✗          | ✗       | ✗     |

## Scenarios

  Given coupon with 3 payments
  When admin deletes coupon
  Then 422, "Cannot delete coupon with existing payments"
