# Student — Behavioral Spec

## Contracts

  invariant: name present
  invariant: email present, format URI::MailTo::EMAIL_REGEXP
  invariant: organization_id present

## Authorization

| Action   | admin | instructor | student | guest |
|----------|-------|------------|---------|-------|
| index    | ✓     | ✓          | ✗       | ✗     |
| show     | ✓     | ✓          | own     | ✗     |
| create   | ✓     | ✗          | ✗       | ✗     |
| update   | ✓     | ✗          | own     | ✗     |
| destroy  | ✓     | ✗          | ✗       | ✗     |

## Scenarios

  Given student with 1 active enrollment
  When admin calls DELETE /students/:id
  Then 422, errors: ["Cannot delete student with existing enrollments"]
