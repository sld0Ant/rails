# Instructor — Behavioral Spec

## Contracts

  invariant: name present
  invariant: email present, format URI::MailTo::EMAIL_REGEXP
  invariant: organization_id present

## Authorization

| Action   | admin | instructor | student | guest |
|----------|-------|------------|---------|-------|
| index    | ✓     | ✓          | ✓       | ✓     |
| show     | ✓     | ✓          | ✓       | ✓     |
| create   | ✓     | ✗          | ✗       | ✗     |
| update   | ✓     | own        | ✗       | ✗     |
| destroy  | ✓     | ✗          | ✗       | ✗     |

## Scenarios

  Given instructor with 2 courses
  When admin calls DELETE /instructors/:id
  Then 422, errors: ["Cannot delete instructor with existing courses"]
