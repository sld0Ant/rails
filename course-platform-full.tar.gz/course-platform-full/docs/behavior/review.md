# Review — Behavioral Spec

## Contracts

  invariant: course_id present
  invariant: student_id present
  invariant: rating 1..5
  invariant: unique(course_id, student_id)

  # Create
  pre:  student enrolled (active or completed), not cancelled
  post: course.average_rating recalculated via SQL AVG

  # Update
  post: course.average_rating recalculated via SQL AVG

  # Destroy
  post: course.average_rating recalculated (nil if no reviews left)

## Authorization

| Action   | admin | instructor | student  | guest     |
|----------|-------|------------|----------|-----------|
| index    | ✓     | ✓          | ✓        | published |
| show     | ✓     | ✓          | ✓        | published |
| create   | ✓     | ✗          | enrolled | ✗         |
| update   | ✓     | ✗          | own      | ✗         |
| destroy  | ✓     | ✗          | own      | ✗         |

## Scenarios

  Given student not enrolled in course
  When student creates review
  Then 422, "Must be enrolled to review"

  Given student with cancelled enrollment
  When student creates review
  Then 422, "Must be enrolled to review"

  Given student already reviewed course
  When student creates another review
  Then 422, "Already reviewed this course"

  Given course with reviews [5, 3, 4]
  When student deletes review (rating 3)
  Then course.average_rating = 4.5

  Given course with 1 review
  When that review is deleted
  Then course.average_rating = nil

## Side Effects

  @on(create): recalculate course.average_rating
  @on(update): recalculate course.average_rating
  @on(destroy): recalculate course.average_rating
