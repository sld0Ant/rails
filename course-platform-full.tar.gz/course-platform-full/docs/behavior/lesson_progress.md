# LessonProgress — Behavioral Spec

## Contracts

  invariant: enrollment_id present
  invariant: lesson_id present
  invariant: status in %w[not_started started completed]
  invariant: unique(enrollment_id, lesson_id)

  # Create
  post: status = "started", started_at = Time.current

  # Update (complete)
  pre:  cannot revert from completed to started
  post: status = "completed", completed_at = Time.current
  post: recalculate enrollment.progress_percent via SQL COUNT
  post: if progress_percent == 100 → auto-complete enrollment

## Authorization

| Action   | admin | instructor   | student         | guest |
|----------|-------|--------------|-----------------|-------|
| index    | ✓     | own courses  | own enrollment  | ✗     |
| show     | ✓     | own courses  | own enrollment  | ✗     |
| create   | ✓     | ✗            | own enrollment  | ✗     |
| update   | ✓     | ✗            | own enrollment  | ✗     |

## Scenarios

  Given enrollment with 6 lessons, 5 completed
  When student completes lesson 6
  Then progress_percent = 100
  Then enrollment status → completed, completed_at set
  Then certificate created with UUID
  Then notification: "Certificate issued for {course.title}"

  Given lesson_progress with status "completed"
  When student updates status to "started"
  Then 422, "Cannot revert completed lesson"

## Side Effects

  @on(update to completed): recalculate enrollment.progress_percent
  @on(progress 100%): auto-complete enrollment, create certificate, notify
