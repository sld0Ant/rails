# Payment — Behavioral Spec

## Contracts

  invariant: enrollment_id present
  invariant: amount_cents > 0
  invariant: net_amount_cents >= 0, readonly (calculated)
  invariant: currency present
  invariant: status in %w[pending confirmed refunded]

  # Create
  pre:  course.price_cents > 0 (no payment for free courses)
  pre:  no existing pending/confirmed payment for this enrollment
  post: amount_cents = course.price_cents
  post: currency = course.currency
  post: if coupon_id given, validate and apply discount:
        - coupon.active == true
        - Time.current between starts_at..expires_at
        - used_count < max_uses (if set)
        - amount_cents >= min_purchase_cents (if set)
        - fixed discount: coupon.currency == course.currency
        - net_amount_cents = amount - discount, min 0
        - coupon.used_count += 1 (atomic SQL)
  post: if net_amount_cents == 0 → auto-confirm (status: confirmed, paid_at: Time.current)
  post: else status = pending

  # Confirm
  post: paid_at = Time.current

  # Refund
  post: refunded_at = Time.current
  post: if coupon used → coupon.used_count -= 1 (atomic SQL)

## Authorization

| Action   | admin | instructor | student          | guest |
|----------|-------|------------|------------------|-------|
| index    | ✓     | ✗          | own (via enroll) | ✗     |
| show     | ✓     | ✗          | own (via enroll) | ✗     |
| create   | ✓     | ✗          | ✓                | ✗     |
| confirm  | ✓     | ✗          | ✗                | ✗     |
| refund   | ✓     | ✗          | ✗                | ✗     |

## Lifecycle

  [pending] --confirm--> [confirmed] --refund--> [refunded]

  No return from any state.

## Scenarios

  Given course with price_cents 0
  When student creates payment
  Then 422, "Course is free"

  Given enrollment with confirmed payment
  When student creates another payment
  Then 422, "Active payment already exists"

  Given payment with coupon (20%, course price 5000)
  When created
  Then net_amount_cents = 4000, coupon.used_count += 1

  Given payment with coupon, net_amount_cents = 0
  When created
  Then status = "confirmed", paid_at set automatically

  Given confirmed payment with coupon
  When admin refunds
  Then refunded_at set, coupon.used_count -= 1

## Side Effects

  @on(confirm): notification to student, event: "payment",
                title: "Payment confirmed for {course.title}"
  @on(refund): coupon.used_count -= 1 (if coupon was used)
