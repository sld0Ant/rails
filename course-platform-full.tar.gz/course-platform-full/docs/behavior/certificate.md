# Certificate — Behavioral Spec

## Contracts

  invariant: enrollment_id present
  invariant: certificate_number present, UUID v4, readonly
  invariant: issued_at present, readonly

  No create endpoint — created automatically on enrollment completion.

## Authorization

| Action   | admin | instructor   | student          | guest |
|----------|-------|--------------|------------------|-------|
| index    | ✓     | own courses  | own (via enroll) | ✗     |
| show     | ✓     | own courses  | own (via enroll) | ✗     |
| destroy  | ✓     | ✗            | ✗                | ✗     |

## Side Effects

  @on(create): notification to student, event: "certificate",
               title: "Certificate issued for {course.title}"
