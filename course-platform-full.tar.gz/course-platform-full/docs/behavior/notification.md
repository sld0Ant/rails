# Notification — Behavioral Spec

## Contracts

  invariant: exactly one of student_id/instructor_id filled (XOR)
  invariant: event_type in %w[enrollment publish payment certificate]
  invariant: title present

## Authorization

| Action    | admin | instructor | student | guest |
|-----------|-------|------------|---------|-------|
| index     | ✓     | own        | own     | ✗     |
| show      | ✓     | own        | own     | ✗     |
| mark_read | ✓     | own        | own     | ✗     |

No create/update/destroy endpoints — created by side effects only.
mark_read: PATCH /notifications/:id/mark_read → read_at = Time.current

## Scenarios

  Given notification belonging to student A
  When student B calls PATCH /notifications/:id/mark_read
  Then 403, "Forbidden"

  Given notification already read
  When owner calls mark_read
  Then 200 (idempotent, read_at stays)
