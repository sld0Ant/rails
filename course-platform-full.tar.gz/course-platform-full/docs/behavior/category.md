# Category — Behavioral Spec

## Contracts

  invariant: name present
  invariant: slug present
  invariant: position >= 0
  invariant: max 1 level nesting — if parent_id set, parent.parent_id must be nil

## Authorization

| Action   | admin | instructor | student | guest |
|----------|-------|------------|---------|-------|
| index    | ✓     | ✓          | ✓       | ✓     |
| show     | ✓     | ✓          | ✓       | ✓     |
| create   | ✓     | ✗          | ✗       | ✗     |
| update   | ✓     | ✗          | ✗       | ✗     |
| destroy  | ✓     | ✗          | ✗       | ✗     |

## Scenarios

  Given category A (parent_id: nil) with child B
  When admin creates category C with parent_id: B.id
  Then 422, errors: ["Cannot nest deeper than 1 level"]

  Given category with 3 courses
  When admin deletes category
  Then courses.category_id set to nil (nullify)
