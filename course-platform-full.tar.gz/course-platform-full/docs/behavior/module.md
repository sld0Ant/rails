# Module — Behavioral Spec

## Contracts

  invariant: title present
  invariant: course_id present
  invariant: position >= 1

## Authorization

| Action   | admin | instructor  | student  | guest     |
|----------|-------|-------------|----------|-----------|
| index    | ✓     | ✓           | enrolled | published |
| show     | ✓     | ✓           | enrolled | published |
| create   | ✓     | own course  | ✗        | ✗         |
| update   | ✓     | own course  | ✗        | ✗         |
| destroy  | ✓     | own course  | ✗        | ✗         |

## Scenarios

  Given module destroyed
  Then all lessons in module cascade-deleted
