class Course < ApplicationEntity
  attribute :id, :integer
  attribute :organization_id, :integer
  attribute :instructor_id, :integer
  attribute :category_id, :integer
  attribute :title, :string
  attribute :description, :string
  attribute :price_cents, :integer, default: 0
  attribute :currency, :string, default: "USD"
  attribute :max_students, :integer
  attribute :enrollments_count, :integer
  attribute :average_rating, :decimal
  attribute :status, :string, default: "draft"
  attribute :published_at, :datetime
  attribute :created_at, :datetime
  attribute :updated_at, :datetime

  validates :title, presence: true
  validates :organization_id, presence: true
  validates :instructor_id, presence: true
  validates :price_cents, numericality: { greater_than_or_equal_to: 0 }
  validates :currency, presence: true
  validates :status, inclusion: { in: %w[draft published archived] }
  validates :max_students, numericality: { greater_than: 0, allow_nil: true }

  transitions :status,
    publish: { from: "draft", to: "published" },
    archive: { from: %w[draft published], to: "archived" }
end
