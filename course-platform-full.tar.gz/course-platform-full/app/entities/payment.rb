class Payment < ApplicationEntity
  attribute :id, :integer
  attribute :enrollment_id, :integer
  attribute :coupon_id, :integer
  attribute :amount_cents, :integer
  attribute :net_amount_cents, :integer
  attribute :currency, :string
  attribute :status, :string, default: "pending"
  attribute :paid_at, :datetime
  attribute :refunded_at, :datetime
  attribute :created_at, :datetime
  attribute :updated_at, :datetime

  validates :enrollment_id, presence: true
  validates :amount_cents, numericality: { greater_than: 0 }
  validates :net_amount_cents, numericality: { greater_than_or_equal_to: 0 }
  validates :currency, presence: true
  validates :status, inclusion: { in: %w[pending confirmed refunded] }

  transitions :status,
    confirm: { from: "pending", to: "confirmed" },
    refund:  { from: "confirmed", to: "refunded" }
end
