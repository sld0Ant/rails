class CourseModule < ApplicationEntity
  attribute :id, :integer
  attribute :course_id, :integer
  attribute :title, :string
  attribute :position, :integer
  attribute :created_at, :datetime
  attribute :updated_at, :datetime

  validates :title, presence: true
  validates :course_id, presence: true
  validates :position, numericality: { greater_than_or_equal_to: 1 }
end
