class Category < ApplicationEntity
  attribute :id, :integer
  attribute :parent_id, :integer
  attribute :name, :string
  attribute :slug, :string
  attribute :position, :integer
  attribute :created_at, :datetime
  attribute :updated_at, :datetime

  validates :name, presence: true
  validates :slug, presence: true
end
