class LessonProgress < ApplicationEntity
  attribute :id, :integer
  attribute :enrollment_id, :integer
  attribute :lesson_id, :integer
  attribute :status, :string, default: "not_started"
  attribute :started_at, :datetime
  attribute :completed_at, :datetime
  attribute :created_at, :datetime
  attribute :updated_at, :datetime

  validates :enrollment_id, presence: true
  validates :lesson_id, presence: true
  validates :status, inclusion: { in: %w[not_started started completed] }
end
