class Organization < ApplicationEntity
  attribute :id, :integer
  attribute :name, :string
  attribute :slug, :string
  attribute :plan, :string
  attribute :max_courses, :integer
  attribute :max_students, :integer
  attribute :logo_url, :string
  attribute :created_at, :datetime
  attribute :updated_at, :datetime

  validates :name, presence: true
  validates :slug, presence: true
  validates :plan, inclusion: { in: %w[free pro enterprise] }

  PLAN_LIMITS = {
    "free"       => { max_courses: 3,   max_students: 100 },
    "pro"        => { max_courses: 50,  max_students: 5000 },
    "enterprise" => { max_courses: nil, max_students: nil }
  }.freeze
end
