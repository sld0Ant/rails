class Review < ApplicationEntity
  attribute :id, :integer
  attribute :course_id, :integer
  attribute :student_id, :integer
  attribute :rating, :integer
  attribute :body, :string
  attribute :created_at, :datetime
  attribute :updated_at, :datetime

  validates :course_id, presence: true
  validates :student_id, presence: true
  validates :rating, inclusion: { in: 1..5 }
end
