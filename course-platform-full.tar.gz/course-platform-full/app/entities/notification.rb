class Notification < ApplicationEntity
  attribute :id, :integer
  attribute :student_id, :integer
  attribute :instructor_id, :integer
  attribute :event_type, :string
  attribute :title, :string
  attribute :body, :string
  attribute :read_at, :datetime
  attribute :created_at, :datetime
  attribute :updated_at, :datetime

  validates :event_type, inclusion: { in: %w[enrollment publish payment certificate] }
  validates :title, presence: true
  validate :exactly_one_recipient

  private

  def exactly_one_recipient
    has_student = student_id.present?
    has_instructor = instructor_id.present?
    unless has_student ^ has_instructor
      errors.add(:base, "Exactly one of student_id or instructor_id must be present")
    end
  end
end
