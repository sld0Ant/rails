class ApplicationEntity
  include ActiveModel::API
  include ActiveModel::Attributes
  include ActiveModel::Serializers::JSON

  class_attribute :transitions_config, default: {}
  class_attribute :state_field, default: nil
  class_attribute :aggregate_root, default: false
  class_attribute :aggregate_parent, default: nil

  def self.transitions(field, **config)
    self.state_field = field.to_s
    self.transitions_config = config
  end

  def self.aggregate(parent_name)
    self.aggregate_parent = parent_name.to_s
  end

  def persisted? = id.present?

  def can_transition?(name)
    cfg = self.class.transitions_config[name.to_sym]
    return false unless cfg

    current = send(self.class.state_field).to_s
    Array(cfg[:from]).map(&:to_s).include?(current)
  end

  def transition!(name)
    cfg = self.class.transitions_config[name.to_sym]
    raise "Unknown transition: #{name}" unless cfg

    unless can_transition?(name)
      errors.add(self.class.state_field, "cannot transition '#{name}' from '#{send(self.class.state_field)}'")
      return self
    end

    send("#{self.class.state_field}=", cfg[:to])
    self
  end
end
