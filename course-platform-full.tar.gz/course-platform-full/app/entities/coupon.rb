class Coupon < ApplicationEntity
  attribute :id, :integer
  attribute :code, :string
  attribute :discount_type, :string
  attribute :discount_value, :integer
  attribute :currency, :string
  attribute :min_purchase_cents, :integer
  attribute :max_uses, :integer
  attribute :used_count, :integer, default: 0
  attribute :starts_at, :datetime
  attribute :expires_at, :datetime
  attribute :active, :boolean, default: true
  attribute :created_at, :datetime
  attribute :updated_at, :datetime

  validates :code, presence: true
  validates :discount_type, inclusion: { in: %w[percent fixed] }
  validates :discount_value, numericality: { greater_than: 0 }
  validates :starts_at, presence: true
  validates :expires_at, presence: true
end
