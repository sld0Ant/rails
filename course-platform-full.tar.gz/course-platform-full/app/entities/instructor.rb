class Instructor < ApplicationEntity
  attribute :id, :integer
  attribute :organization_id, :integer
  attribute :name, :string
  attribute :email, :string
  attribute :bio, :string
  attribute :avatar_url, :string
  attribute :created_at, :datetime
  attribute :updated_at, :datetime

  validates :name, presence: true
  validates :email, presence: true, format: { with: URI::MailTo::EMAIL_REGEXP }
  validates :organization_id, presence: true
end
