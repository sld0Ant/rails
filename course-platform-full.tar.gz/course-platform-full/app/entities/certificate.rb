class Certificate < ApplicationEntity
  attribute :id, :integer
  attribute :enrollment_id, :integer
  attribute :certificate_number, :string
  attribute :issued_at, :datetime
  attribute :created_at, :datetime
  attribute :updated_at, :datetime

  validates :enrollment_id, presence: true
  validates :certificate_number, presence: true
  validates :issued_at, presence: true
end
