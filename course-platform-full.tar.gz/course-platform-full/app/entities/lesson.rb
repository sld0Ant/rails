class Lesson < ApplicationEntity
  attribute :id, :integer
  attribute :module_id, :integer
  attribute :title, :string
  attribute :content, :string
  attribute :lesson_type, :string, default: "text"
  attribute :video_url, :string
  attribute :position, :integer, default: 1
  attribute :duration_minutes, :integer
  attribute :created_at, :datetime
  attribute :updated_at, :datetime

  validates :title, presence: true
  validates :module_id, presence: true
  validates :lesson_type, inclusion: { in: %w[video text quiz] }
  validates :position, numericality: { greater_than_or_equal_to: 1 }
  validates :duration_minutes, numericality: { greater_than: 0, allow_nil: true }
end
