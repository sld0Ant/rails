class Enrollment < ApplicationEntity
  attribute :id, :integer
  attribute :course_id, :integer
  attribute :student_id, :integer
  attribute :status, :string, default: "active"
  attribute :progress_percent, :integer, default: 0
  attribute :enrolled_at, :datetime
  attribute :completed_at, :datetime
  attribute :created_at, :datetime
  attribute :updated_at, :datetime

  validates :course_id, presence: true
  validates :student_id, presence: true
  validates :status, inclusion: { in: %w[active completed cancelled] }
  validates :progress_percent, numericality: { in: 0..100 }, allow_nil: true

  transitions :status,
    complete: { from: "active", to: "completed" },
    cancel:   { from: "active", to: "cancelled" }
end
