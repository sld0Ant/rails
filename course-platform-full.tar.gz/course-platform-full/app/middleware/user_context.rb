class UserContext
  def initialize(app)
    @app = app
  end

  def call(env)
    Thread.current[:user_role] = env["HTTP_X_USER_ROLE"]
    Thread.current[:user_id] = env["HTTP_X_USER_ID"]&.to_i
    @app.call(env)
  ensure
    Thread.current[:user_role] = nil
    Thread.current[:user_id] = nil
  end
end
