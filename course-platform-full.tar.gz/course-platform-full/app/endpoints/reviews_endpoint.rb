class ReviewsEndpoint < ApplicationEndpoint
  resource :review,
    service: ReviewService,
    permit: [:course_id, :student_id, :rating, :body],
    sort: [:rating, :created_at],
    filter: [:course_id, :student_id, :rating],
    per_page: 10,
    relations: {
      course: { kind: :belongs_to, resource: "Course" },
      student: { kind: :belongs_to, resource: "Student" }
    },
    authorize: {
      index:   ["*"],
      show:    ["*"],
      create:  [:admin, :student],
      update:  [:admin, :student],
      destroy: [:admin, :student]
    }
end
