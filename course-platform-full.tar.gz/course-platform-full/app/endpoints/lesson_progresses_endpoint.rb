class LessonProgressesEndpoint < ApplicationEndpoint
  resource :lesson_progress,
    service: LessonProgressService,
    permit: [:enrollment_id, :lesson_id, :status],
    sort: [:created_at],
    filter: [:enrollment_id, :lesson_id, :status],
    per_page: 50,
    relations: {
      enrollment: { kind: :belongs_to, resource: "Enrollment" },
      lesson: { kind: :belongs_to, resource: "Lesson" }
    },
    authorize: {
      index:  [:admin, :instructor, :student],
      show:   [:admin, :instructor, :student],
      create: [:admin, :student],
      update: [:admin, :student]
    }
end
