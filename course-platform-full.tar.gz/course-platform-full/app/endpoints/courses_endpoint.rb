class CoursesEndpoint < ApplicationEndpoint
  resource :course,
    service: CourseService,
    permit: [:organization_id, :instructor_id, :category_id, :title, :description, :price_cents, :currency, :max_students],
    sort: [:title, :price_cents, :created_at, :average_rating],
    filter: [:status, :category_id, :instructor_id, :organization_id],
    search: [:title, :description],
    per_page: 20,
    relations: {
      organization: { kind: :belongs_to, resource: "Organization" },
      instructor: { kind: :belongs_to, resource: "Instructor" },
      category: { kind: :belongs_to, resource: "Category" }
    },
    authorize: {
      index:   ["*"],
      show:    ["*"],
      create:  [:admin, :instructor],
      update:  [:admin, :instructor],
      destroy: [:admin, :instructor],
      publish: [:admin, :instructor],
      archive: [:admin, :instructor]
    }
end
