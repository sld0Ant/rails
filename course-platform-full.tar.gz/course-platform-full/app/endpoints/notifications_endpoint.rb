class NotificationsEndpoint < ApplicationEndpoint
  resource :notification,
    service: NotificationService,
    permit: [],
    sort: [:created_at],
    filter: [:event_type, :read],
    per_page: 25,
    relations: {
      student: { kind: :belongs_to, resource: "Student" },
      instructor: { kind: :belongs_to, resource: "Instructor" }
    },
    authorize: {
      index:     [:admin, :instructor, :student],
      show:      [:admin, :instructor, :student],
      mark_read: [:admin, :instructor, :student]
    }
end
