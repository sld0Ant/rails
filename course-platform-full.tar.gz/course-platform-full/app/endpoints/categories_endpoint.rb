class CategoriesEndpoint < ApplicationEndpoint
  resource :category,
    service: CategoryService,
    permit: [:name, :slug, :parent_id, :position],
    sort: [:position, :name],
    filter: [:parent_id],
    per_page: 50,
    relations: { parent: { kind: :belongs_to, resource: "Category" } },
    authorize: {
      index:   ["*"],
      show:    ["*"],
      create:  [:admin],
      update:  [:admin],
      destroy: [:admin]
    }
end
