class ModulesEndpoint < ApplicationEndpoint
  resource :course_module,
    service: ModuleService,
    permit: [:course_id, :title, :position],
    sort: [:position],
    filter: [:course_id],
    per_page: 50,
    relations: { course: { kind: :belongs_to, resource: "Course" } },
    authorize: {
      index:   ["*"],
      show:    ["*"],
      create:  [:admin, :instructor],
      update:  [:admin, :instructor],
      destroy: [:admin, :instructor]
    }
end
