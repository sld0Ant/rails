class ApplicationEndpoint
  class_attribute :resource_name
  class_attribute :service_class
  class_attribute :permitted_params
  class_attribute :sortable_fields, default: []
  class_attribute :filterable_fields, default: []
  class_attribute :searchable_fields, default: []
  class_attribute :default_per_page, default: nil
  class_attribute :cache_config, default: {}
  class_attribute :resource_relations, default: {}
  class_attribute :authorize_config, default: {}

  class << self
    def resource(name, service:, permit: [], sort: [], filter: [], search: [], per_page: nil, cache: {}, relations: {}, authorize: {})
      self.resource_name = name
      self.service_class = service
      self.permitted_params = permit
      self.sortable_fields = sort.map(&:to_s)
      self.filterable_fields = filter.map(&:to_s)
      self.searchable_fields = search.map(&:to_s)
      self.default_per_page = per_page
      self.cache_config = cache
      self.resource_relations = relations
      self.authorize_config = authorize
    end
  end

  def service = @service ||= self.class.service_class.new

  def index(params)
    if collection_configured?
      result = service.list_all(**collection_params(params))
      result[:data] = result[:data].map { |e| with_links(e.as_json) }
      respond(200, result.to_json, :index)
    else
      entities = service.list_all
      respond(200, entities.map { |e| with_links(e.as_json) }.to_json, :index)
    end
  end

  def show(params)
    entity = service.find(params[:id])
    if entity.respond_to?(:errors) && entity.errors.any?
      [422, json_headers, [{ errors: entity.errors.as_json }.to_json]]
    else
      respond(200, with_links(entity.as_json).to_json, :show)
    end
  end

  def create(params)
    permitted = params[resource_name]&.slice(*permitted_params) || {}
    entity = service.create(permitted)
    if entity.errors.empty?
      [201, json_headers, [with_links(entity.as_json).to_json]]
    else
      [422, json_headers, [{ errors: entity.errors.as_json }.to_json]]
    end
  end

  def update(params)
    permitted = params[resource_name]&.slice(*permitted_params) || {}
    entity = service.update(params[:id], permitted)
    if entity.errors.empty?
      [200, json_headers, [with_links(entity.as_json).to_json]]
    else
      [422, json_headers, [{ errors: entity.errors.as_json }.to_json]]
    end
  end

  def destroy(params)
    result = service.destroy(params[:id])
    if result.respond_to?(:errors) && result.errors.any?
      [422, json_headers, [{ errors: result.errors.as_json }.to_json]]
    else
      [204, {}, []]
    end
  end

  def transition(params, transition_name)
    entity = service.perform_transition(params[:id], transition_name.to_sym)
    if entity.errors.empty?
      [200, json_headers, [with_links(entity.as_json).to_json]]
    else
      [422, json_headers, [{ errors: entity.errors.as_json }.to_json]]
    end
  end

  private

  def json_headers = { "content-type" => "application/json" }
  def resource_name = self.class.resource_name
  def permitted_params = self.class.permitted_params
  def plural_name = self.class.resource_name.to_s.pluralize

  def respond(status, body, action, headers = json_headers)
    apply_cache_headers(action, headers)
    [status, headers, [body]]
  end

  def entity_class
    @entity_class ||= self.class.resource_name.to_s.camelize.constantize
  end

  def with_links(entity_hash)
    links = { "self" => "/#{plural_name}/#{entity_hash['id']}" }

    self.class.resource_relations.each do |rel_name, rel_info|
      case rel_info[:kind].to_s
      when "belongs_to"
        fk = "#{rel_name}_id"
        fk_val = entity_hash[fk]
        links[rel_name.to_s] = "/#{rel_info[:resource].to_s.downcase.pluralize}/#{fk_val}" if fk_val
      when "has_many"
        links[rel_name.to_s] = "/#{plural_name}/#{entity_hash['id']}/#{rel_name}"
      end
    end

    if entity_class.respond_to?(:transitions_config) && entity_class.transitions_config.any?
      state_val = entity_hash[entity_class.state_field].to_s
      entity_class.transitions_config.each do |t_name, t_cfg|
        if Array(t_cfg[:from]).map(&:to_s).include?(state_val)
          links[t_name.to_s] = { "href" => "/#{plural_name}/#{entity_hash['id']}/#{t_name}", "method" => "POST" }
        end
      end
    end

    entity_hash.merge("_links" => links)
  end

  def apply_cache_headers(action, headers)
    cfg = self.class.cache_config[action]
    return unless cfg

    parts = []
    parts << "public" if cfg[:public]
    parts << "max-age=#{cfg[:max_age]}" if cfg[:max_age]
    headers["cache-control"] = parts.join(", ") if parts.any?
  end

  def collection_configured?
    self.class.default_per_page || self.class.sortable_fields.any? || self.class.filterable_fields.any? || self.class.searchable_fields.any?
  end

  def collection_params(params)
    opts = {}
    opts[:page] = params[:page] if params[:page]
    opts[:per] = params[:per_page] || self.class.default_per_page
    opts[:sort] = params[:sort] if params[:sort].present? && self.class.sortable_fields.include?(params[:sort].to_s)

    if params[:filter].is_a?(Hash)
      opts[:filter] = params[:filter].slice(*self.class.filterable_fields).to_h
    end

    if params[:search].present? && self.class.searchable_fields.any?
      opts[:search] = params[:search]
      opts[:search_fields] = self.class.searchable_fields
    end

    opts.compact
  end
end
