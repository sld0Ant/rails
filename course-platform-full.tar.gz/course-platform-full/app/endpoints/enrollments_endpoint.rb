class EnrollmentsEndpoint < ApplicationEndpoint
  resource :enrollment,
    service: EnrollmentService,
    permit: [:course_id, :student_id],
    sort: [:created_at, :progress_percent],
    filter: [:course_id, :student_id, :status],
    per_page: 25,
    relations: {
      course: { kind: :belongs_to, resource: "Course" },
      student: { kind: :belongs_to, resource: "Student" }
    },
    authorize: {
      index:  [:admin, :instructor, :student],
      show:   [:admin, :instructor, :student],
      create: [:admin, :student],
      cancel: [:admin, :student]
    }
end
