class LessonsEndpoint < ApplicationEndpoint
  resource :lesson,
    service: LessonService,
    permit: [:module_id, :title, :content, :lesson_type, :video_url, :position, :duration_minutes],
    sort: [:position],
    filter: [:module_id],
    search: [:title],
    per_page: 50,
    relations: { module: { kind: :belongs_to, resource: "Module" } },
    authorize: {
      index:   ["*"],
      show:    ["*"],
      create:  [:admin, :instructor],
      update:  [:admin, :instructor],
      destroy: [:admin, :instructor]
    }
end
