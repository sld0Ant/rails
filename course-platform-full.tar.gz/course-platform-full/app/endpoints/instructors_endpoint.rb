class InstructorsEndpoint < ApplicationEndpoint
  resource :instructor,
    service: InstructorService,
    permit: [:organization_id, :name, :email, :bio, :avatar_url],
    sort: [:name, :created_at],
    filter: [:organization_id],
    search: [:name, :email],
    per_page: 20,
    relations: { organization: { kind: :belongs_to, resource: "Organization" } },
    authorize: {
      index:   ["*"],
      show:    ["*"],
      create:  [:admin],
      update:  [:admin, :instructor],
      destroy: [:admin]
    }
end
