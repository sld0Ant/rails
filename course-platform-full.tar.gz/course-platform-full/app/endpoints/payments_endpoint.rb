class PaymentsEndpoint < ApplicationEndpoint
  resource :payment,
    service: PaymentService,
    permit: [:enrollment_id, :coupon_id],
    sort: [:created_at, :amount_cents],
    filter: [:enrollment_id, :status],
    per_page: 20,
    relations: {
      enrollment: { kind: :belongs_to, resource: "Enrollment" },
      coupon: { kind: :belongs_to, resource: "Coupon" }
    },
    authorize: {
      index:   [:admin, :student],
      show:    [:admin, :student],
      create:  [:admin, :student],
      confirm: [:admin],
      refund:  [:admin]
    }
end
