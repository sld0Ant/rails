class CouponsEndpoint < ApplicationEndpoint
  resource :coupon,
    service: CouponService,
    permit: [:code, :discount_type, :discount_value, :currency, :min_purchase_cents, :max_uses, :starts_at, :expires_at, :active],
    sort: [:created_at, :expires_at],
    filter: [:active, :discount_type],
    search: [:code],
    per_page: 20,
    authorize: {
      index:   [:admin],
      show:    [:admin],
      create:  [:admin],
      update:  [:admin],
      destroy: [:admin]
    }
end
