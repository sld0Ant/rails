class OrganizationsEndpoint < ApplicationEndpoint
  resource :organization,
    service: OrganizationService,
    permit: [:name, :slug, :plan, :max_courses, :max_students, :logo_url],
    sort: [:name, :created_at],
    filter: [:plan],
    per_page: 20,
    authorize: {
      index:   [:admin],
      show:    [:admin, :instructor, :student],
      create:  [:admin],
      update:  [:admin],
      destroy: [:admin]
    }
end
