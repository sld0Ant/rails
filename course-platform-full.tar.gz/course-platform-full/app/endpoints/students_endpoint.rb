class StudentsEndpoint < ApplicationEndpoint
  resource :student,
    service: StudentService,
    permit: [:organization_id, :name, :email, :avatar_url],
    sort: [:name, :created_at],
    filter: [:organization_id],
    search: [:name, :email],
    per_page: 25,
    relations: { organization: { kind: :belongs_to, resource: "Organization" } },
    authorize: {
      index:   [:admin, :instructor],
      show:    [:admin, :instructor, :student],
      create:  [:admin],
      update:  [:admin, :student],
      destroy: [:admin]
    }
end
