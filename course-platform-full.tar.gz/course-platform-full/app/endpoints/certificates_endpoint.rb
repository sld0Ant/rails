class CertificatesEndpoint < ApplicationEndpoint
  resource :certificate,
    service: CertificateService,
    permit: [],
    sort: [:issued_at],
    filter: [:enrollment_id],
    per_page: 20,
    relations: {
      enrollment: { kind: :belongs_to, resource: "Enrollment" }
    },
    authorize: {
      index:   [:admin, :instructor, :student],
      show:    [:admin, :instructor, :student],
      destroy: [:admin]
    }
end
