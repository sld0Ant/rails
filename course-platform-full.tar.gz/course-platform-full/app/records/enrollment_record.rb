class EnrollmentRecord < ApplicationRecord
  self.table_name = "enrollments"
  belongs_to :course, class_name: "CourseRecord"
  belongs_to :student, class_name: "StudentRecord"
  has_many :lesson_progresses, class_name: "LessonProgressRecord", foreign_key: "enrollment_id", dependent: :destroy
  has_many :payments, class_name: "PaymentRecord", foreign_key: "enrollment_id", dependent: :destroy
  has_many :certificates, class_name: "CertificateRecord", foreign_key: "enrollment_id", dependent: :destroy
end
