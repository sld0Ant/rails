class PaymentRecord < ApplicationRecord
  self.table_name = "payments"
  belongs_to :enrollment, class_name: "EnrollmentRecord"
  belongs_to :coupon, class_name: "CouponRecord", optional: true
end
