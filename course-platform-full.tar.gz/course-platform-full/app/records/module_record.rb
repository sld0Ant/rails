class ModuleRecord < ApplicationRecord
  self.table_name = "modules"
  belongs_to :course, class_name: "CourseRecord"
  has_many :lessons, class_name: "LessonRecord", foreign_key: "module_id", dependent: :destroy
end
