class InstructorRecord < ApplicationRecord
  self.table_name = "instructors"
  belongs_to :organization, class_name: "OrganizationRecord"
  has_many :courses, class_name: "CourseRecord", foreign_key: "instructor_id", dependent: :restrict_with_error
  has_many :notifications, class_name: "NotificationRecord", foreign_key: "instructor_id"
end
