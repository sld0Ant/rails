class CategoryRecord < ApplicationRecord
  self.table_name = "categories"
  belongs_to :parent, class_name: "CategoryRecord", optional: true
  has_many :children, class_name: "CategoryRecord", foreign_key: "parent_id"
  has_many :courses, class_name: "CourseRecord", foreign_key: "category_id"
end
