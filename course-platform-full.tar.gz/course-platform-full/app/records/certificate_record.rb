class CertificateRecord < ApplicationRecord
  self.table_name = "certificates"
  belongs_to :enrollment, class_name: "EnrollmentRecord"
end
