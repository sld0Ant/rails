class CourseRecord < ApplicationRecord
  self.table_name = "courses"
  belongs_to :organization, class_name: "OrganizationRecord"
  belongs_to :instructor, class_name: "InstructorRecord"
  belongs_to :category, class_name: "CategoryRecord", optional: true
  has_many :modules, class_name: "ModuleRecord", foreign_key: "course_id", dependent: :destroy
  has_many :enrollments, class_name: "EnrollmentRecord", foreign_key: "course_id", dependent: :restrict_with_error
  has_many :reviews, class_name: "ReviewRecord", foreign_key: "course_id", dependent: :destroy
end
