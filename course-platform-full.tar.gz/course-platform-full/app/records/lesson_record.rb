class LessonRecord < ApplicationRecord
  self.table_name = "lessons"
  belongs_to :module, class_name: "ModuleRecord"
  has_many :lesson_progresses, class_name: "LessonProgressRecord", foreign_key: "lesson_id"
end
