class LessonProgressRecord < ApplicationRecord
  self.table_name = "lesson_progresses"
  belongs_to :enrollment, class_name: "EnrollmentRecord"
  belongs_to :lesson, class_name: "LessonRecord"
end
