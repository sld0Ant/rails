class CouponRecord < ApplicationRecord
  self.table_name = "coupons"
  has_many :payments, class_name: "PaymentRecord", foreign_key: "coupon_id", dependent: :restrict_with_error
end
