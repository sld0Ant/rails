class OrganizationRecord < ApplicationRecord
  self.table_name = "organizations"
  has_many :instructors, class_name: "InstructorRecord", foreign_key: "organization_id", dependent: :restrict_with_error
  has_many :students, class_name: "StudentRecord", foreign_key: "organization_id", dependent: :restrict_with_error
  has_many :courses, class_name: "CourseRecord", foreign_key: "organization_id", dependent: :restrict_with_error
end
