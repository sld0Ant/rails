class ReviewRecord < ApplicationRecord
  self.table_name = "reviews"
  belongs_to :course, class_name: "CourseRecord"
  belongs_to :student, class_name: "StudentRecord"
end
