class StudentRecord < ApplicationRecord
  self.table_name = "students"
  belongs_to :organization, class_name: "OrganizationRecord"
  has_many :enrollments, class_name: "EnrollmentRecord", foreign_key: "student_id", dependent: :restrict_with_error
  has_many :reviews, class_name: "ReviewRecord", foreign_key: "student_id"
  has_many :notifications, class_name: "NotificationRecord", foreign_key: "student_id"
end
