class NotificationRecord < ApplicationRecord
  self.table_name = "notifications"
  belongs_to :student, class_name: "StudentRecord", optional: true
  belongs_to :instructor, class_name: "InstructorRecord", optional: true
end
