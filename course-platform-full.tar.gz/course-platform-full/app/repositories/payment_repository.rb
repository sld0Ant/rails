class PaymentRepository < ApplicationRepository
  self.record_class = PaymentRecord
  self.entity_class = Payment
end
