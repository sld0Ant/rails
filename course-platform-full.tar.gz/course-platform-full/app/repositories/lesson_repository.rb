class LessonRepository < ApplicationRepository
  self.record_class = LessonRecord
  self.entity_class = Lesson
end
