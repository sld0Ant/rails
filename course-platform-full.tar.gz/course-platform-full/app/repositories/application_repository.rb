class ApplicationRepository
  class_attribute :record_class
  class_attribute :entity_class

  def all = record_class.all.map { |r| to_entity(r) }
  def find(id) = to_entity(record_class.find(id))

  def paginate(page: 1, per: 25, sort: nil, filter: {}, search: nil, search_fields: [])
    scope = record_class.all

    filter.each { |k, v| scope = scope.where(k => v) } if filter.any?

    if search.present? && search_fields.any?
      clauses = search_fields.map { |f| "#{f} LIKE ?" }.join(" OR ")
      scope = scope.where(clauses, *search_fields.map { "%#{search}%" })
    end

    scope = scope.order(sort) if sort.present?

    total = scope.count
    records = scope.offset(([page.to_i, 1].max - 1) * per.to_i).limit(per.to_i)

    { data: records.map { |r| to_entity(r) }, meta: { page: page.to_i, per: per.to_i, total: total } }
  end

  def create(attributes)
    entity = entity_class.new(**attributes)
    return entity unless entity.valid?

    record = record_class.create!(attributes)
    to_entity(record)
  rescue ActiveRecord::RecordInvalid => e
    map_record_errors(entity, e.record)
    entity
  end

  def update(id, attributes)
    record = record_class.find(id)
    entity = to_entity_with(record, attributes)
    return entity unless entity.valid?

    record.update!(attributes)
    to_entity(record)
  rescue ActiveRecord::RecordInvalid => e
    map_record_errors(entity, e.record)
    entity
  end

  def destroy(id) = record_class.find(id).destroy!

  private

  def to_entity(record)
    attrs = record.attributes.symbolize_keys.slice(*entity_class.attribute_names.map(&:to_sym))
    entity_class.new(**attrs)
  end

  def to_entity_with(record, overrides)
    attrs = record.attributes.symbolize_keys
      .slice(*entity_class.attribute_names.map(&:to_sym))
      .merge(overrides.symbolize_keys)
    entity_class.new(**attrs)
  end

  def map_record_errors(entity, record)
    record.errors.each { |error| entity.errors.add(error.attribute, error.type, message: error.message) }
  end
end
