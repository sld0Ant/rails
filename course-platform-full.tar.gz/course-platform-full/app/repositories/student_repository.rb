class StudentRepository < ApplicationRepository
  self.record_class = StudentRecord
  self.entity_class = Student
end
