class OrganizationRepository < ApplicationRepository
  self.record_class = OrganizationRecord
  self.entity_class = Organization
end
