class CourseRepository < ApplicationRepository
  self.record_class = CourseRecord
  self.entity_class = Course
end
