class ModuleRepository < ApplicationRepository
  self.record_class = ModuleRecord
  self.entity_class = CourseModule
end
