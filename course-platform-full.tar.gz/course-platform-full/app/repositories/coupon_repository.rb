class CouponRepository < ApplicationRepository
  self.record_class = CouponRecord
  self.entity_class = Coupon
end
