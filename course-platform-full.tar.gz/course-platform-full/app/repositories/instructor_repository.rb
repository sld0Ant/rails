class InstructorRepository < ApplicationRepository
  self.record_class = InstructorRecord
  self.entity_class = Instructor
end
