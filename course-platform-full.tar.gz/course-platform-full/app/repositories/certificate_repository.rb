class CertificateRepository < ApplicationRepository
  self.record_class = CertificateRecord
  self.entity_class = Certificate
end
