class ReviewRepository < ApplicationRepository
  self.record_class = ReviewRecord
  self.entity_class = Review
end
