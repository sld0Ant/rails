class CategoryRepository < ApplicationRepository
  self.record_class = CategoryRecord
  self.entity_class = Category
end
