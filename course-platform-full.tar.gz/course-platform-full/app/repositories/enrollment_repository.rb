class EnrollmentRepository < ApplicationRepository
  self.record_class = EnrollmentRecord
  self.entity_class = Enrollment
end
