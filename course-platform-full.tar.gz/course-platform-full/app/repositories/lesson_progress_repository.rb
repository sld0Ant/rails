class LessonProgressRepository < ApplicationRepository
  self.record_class = LessonProgressRecord
  self.entity_class = LessonProgress
end
