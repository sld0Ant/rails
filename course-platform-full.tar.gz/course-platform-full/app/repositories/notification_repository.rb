class NotificationRepository < ApplicationRepository
  self.record_class = NotificationRecord
  self.entity_class = Notification

  def paginate(page: 1, per: 25, sort: nil, filter: {}, search: nil, search_fields: [], **_opts)
    scope = record_class.all

    if filter.any?
      read_filter = filter.delete("read")
      filter.each { |k, v| scope = scope.where(k => v) }

      if read_filter.present?
        scope = if read_filter.to_s == "true"
          scope.where.not(read_at: nil)
        else
          scope.where(read_at: nil)
        end
      end
    end

    scope = scope.order(sort) if sort.present?

    total = scope.count
    records = scope.offset(([page.to_i, 1].max - 1) * per.to_i).limit(per.to_i)

    { data: records.map { |r| to_entity(r) }, meta: { page: page.to_i, per: per.to_i, total: total } }
  end
end
