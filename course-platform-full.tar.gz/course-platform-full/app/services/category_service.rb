class CategoryService < ApplicationService
  def list_all(**params)
    params.any? ? repository.paginate(**params) : repository.all
  end

  def find(id) = repository.find(id)

  def create(attributes)
    if attributes[:parent_id].present?
      parent = CategoryRecord.find_by(id: attributes[:parent_id])
      if parent&.parent_id.present?
        entity = Category.new(**attributes)
        entity.errors.add(:base, "Cannot nest deeper than 1 level")
        return entity
      end
    end
    repository.create(attributes)
  end

  def update(id, attributes)
    if attributes[:parent_id].present?
      parent = CategoryRecord.find_by(id: attributes[:parent_id])
      if parent&.parent_id.present?
        entity = repository.find(id)
        entity.errors.add(:base, "Cannot nest deeper than 1 level")
        return entity
      end
    end
    repository.update(id, attributes)
  end

  def destroy(id)
    CourseRecord.where(category_id: id).update_all(category_id: nil)
    repository.destroy(id)
    Category.new(id: id)
  end

  private

  def repository = @repository ||= CategoryRepository.new
end
