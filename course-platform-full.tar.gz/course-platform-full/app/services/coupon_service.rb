class CouponService < ApplicationService
  def list_all(**params)
    params.any? ? repository.paginate(**params) : repository.all
  end

  def find(id) = repository.find(id)

  def create(attributes)
    attributes = attributes.dup
    attributes[:used_count] = 0
    attributes[:active] = true if attributes[:active].nil?
    repository.create(attributes)
  end

  def update(id, attributes) = repository.update(id, attributes)

  def destroy(id)
    CouponRecord.find(id).destroy!
    Coupon.new(id: id)
  rescue ActiveRecord::RecordNotDestroyed, ActiveRecord::DeleteRestrictionError
    coupon = repository.find(id)
    coupon.errors.add(:base, "Cannot delete coupon with existing payments")
    coupon
  end

  private

  def repository = @repository ||= CouponRepository.new
end
