class StudentService < ApplicationService
  def list_all(**params)
    params.any? ? repository.paginate(**params) : repository.all
  end

  def find(id)
    student = repository.find(id)
    if Thread.current[:user_role] == "student" && student.id != Thread.current[:user_id]
      student.errors.add(:base, "Forbidden")
    end
    student
  end

  def create(attributes) = repository.create(attributes)

  def update(id, attributes)
    if Thread.current[:user_role] == "student" && id.to_i != Thread.current[:user_id]
      student = repository.find(id)
      student.errors.add(:base, "Forbidden")
      return student
    end
    repository.update(id, attributes)
  end

  def destroy(id)
    StudentRecord.find(id).destroy!
    Student.new(id: id)
  rescue ActiveRecord::RecordNotDestroyed, ActiveRecord::DeleteRestrictionError
    student = repository.find(id)
    student.errors.add(:base, "Cannot delete student with existing enrollments")
    student
  end

  private

  def repository = @repository ||= StudentRepository.new
end
