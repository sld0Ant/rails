class ApplicationService
  def perform_transition(id, transition_name)
    entity = repository.find(id)

    guard_transition(entity, transition_name)
    return entity if entity.errors.any?

    entity.transition!(transition_name)
    return entity if entity.errors.any?

    repository.update(id, { entity.class.state_field => entity.send(entity.class.state_field) })
  end

  private

  def repository = raise NotImplementedError

  def guard_transition(entity, transition_name)
    # Override in subclass to add preconditions.
    # Add errors to entity.errors to block the transition.
  end
end
