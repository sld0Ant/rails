class PaymentService < ApplicationService
  def list_all(**params)
    if Thread.current[:user_role] == "student"
      student_enrollment_ids = EnrollmentRecord
        .where(student_id: Thread.current[:user_id])
        .pluck(:id)
      params[:filter] = (params[:filter] || {}).merge("enrollment_id" => student_enrollment_ids)
    end
    params.any? ? repository.paginate(**params) : repository.all
  end

  def find(id)
    payment = repository.find(id)
    authorize_read!(payment)
    payment
  end

  def create(attributes)
    attributes = attributes.dup
    enrollment = EnrollmentRecord.find(attributes[:enrollment_id])
    course = CourseRecord.find(enrollment.course_id)

    payment = Payment.new(enrollment_id: attributes[:enrollment_id])

    if course.price_cents.nil? || course.price_cents == 0
      payment.errors.add(:base, "Course is free")
      return payment
    end

    existing = PaymentRecord.where(
      enrollment_id: attributes[:enrollment_id],
      status: %w[pending confirmed]
    ).exists?
    if existing
      payment.errors.add(:base, "Active payment already exists")
      return payment
    end

    amount = course.price_cents
    currency = course.currency
    net_amount = amount
    coupon_id = attributes[:coupon_id]

    if coupon_id.present?
      coupon = CouponRecord.find_by(id: coupon_id)
      unless coupon
        payment.errors.add(:base, "Coupon not found")
        return payment
      end

      error = validate_coupon(coupon, amount, currency)
      if error
        payment.errors.add(:base, error)
        return payment
      end

      net_amount = calculate_discount(coupon, amount)
      CouponRecord.where(id: coupon.id).update_all("used_count = used_count + 1")
    end

    auto_confirm = net_amount == 0
    payment_attrs = {
      enrollment_id: enrollment.id,
      coupon_id: coupon_id,
      amount_cents: amount,
      net_amount_cents: net_amount,
      currency: currency,
      status: auto_confirm ? "confirmed" : "pending",
      paid_at: auto_confirm ? Time.current : nil
    }

    result = repository.create(payment_attrs)
    return result if result.errors.any?

    if auto_confirm
      notify_payment_confirmed(result)
    end

    result
  end

  def perform_transition(id, transition_name)
    entity = super
    return entity if entity.errors.any?

    case transition_name.to_sym
    when :confirm
      repository.update(id, paid_at: Time.current)
      entity = repository.find(id)
      notify_payment_confirmed(entity)
    when :refund
      repository.update(id, refunded_at: Time.current)
      entity = repository.find(id)
      if entity.coupon_id.present?
        CouponRecord.where(id: entity.coupon_id).update_all("used_count = used_count - 1")
      end
    end

    entity
  end

  private

  def repository = @repository ||= PaymentRepository.new

  def guard_transition(entity, transition_name)
    # State machine handles from/to validation
  end

  def validate_coupon(coupon, amount, currency)
    return "Coupon is not active" unless coupon.active
    return "Coupon has not started yet" if Time.current < coupon.starts_at
    return "Coupon has expired" if Time.current > coupon.expires_at
    if coupon.max_uses.present? && coupon.used_count >= coupon.max_uses
      return "Coupon usage limit reached"
    end
    if coupon.min_purchase_cents.present? && amount < coupon.min_purchase_cents
      return "Minimum purchase amount not met"
    end
    if coupon.discount_type == "fixed" && coupon.currency != currency
      return "Coupon currency does not match course currency"
    end
    nil
  end

  def calculate_discount(coupon, amount)
    discount = if coupon.discount_type == "percent"
      (amount * coupon.discount_value) / 100
    else
      coupon.discount_value
    end
    [amount - discount, 0].max
  end

  def notify_payment_confirmed(payment)
    enrollment = EnrollmentRecord.find(payment.enrollment_id)
    course = CourseRecord.find(enrollment.course_id)
    NotificationRecord.create!(
      student_id: enrollment.student_id,
      event_type: "payment",
      title: "Payment confirmed for #{course.title}"
    )
  end

  def authorize_read!(payment)
    return if Thread.current[:user_role] == "admin"
    if Thread.current[:user_role] == "student"
      enrollment = EnrollmentRecord.find_by(id: payment.enrollment_id)
      unless enrollment&.student_id == Thread.current[:user_id]
        payment.errors.add(:base, "Forbidden")
      end
    end
  end
end
