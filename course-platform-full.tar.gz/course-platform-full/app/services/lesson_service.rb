class LessonService < ApplicationService
  def list_all(**params)
    params.any? ? repository.paginate(**params) : repository.all
  end

  def find(id) = repository.find(id)
  def create(attributes) = guard_course_owner_via_module(attributes[:module_id]) { repository.create(attributes) }

  def update(id, attributes)
    guard_course_owner_via_module(LessonRecord.find(id).module_id) do
      repository.update(id, attributes)
    end
  end

  def destroy(id)
    guard_course_owner_via_module(LessonRecord.find(id).module_id) do
      repository.destroy(id)
      Lesson.new(id: id)
    end
  end

  private

  def repository = @repository ||= LessonRepository.new

  def guard_course_owner_via_module(module_id)
    if Thread.current[:user_role] == "instructor"
      mod = ModuleRecord.find(module_id)
      course = CourseRecord.find(mod.course_id)
      unless course.instructor_id == Thread.current[:user_id]
        entity = Lesson.new
        entity.errors.add(:base, "Forbidden")
        return entity
      end
    end
    yield
  end
end
