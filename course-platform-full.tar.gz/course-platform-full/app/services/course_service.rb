class CourseService < ApplicationService
  def list_all(**params)
    role = Thread.current[:user_role]
    if role == "student" || role == "guest" || role.nil?
      params[:filter] = (params[:filter] || {}).merge("status" => "published")
    end
    params.any? ? repository.paginate(**params) : repository.all
  end

  def find(id)
    course = repository.find(id)
    role = Thread.current[:user_role]
    if role == "instructor"
      unless course.instructor_id == Thread.current[:user_id] || course.status == "published"
        course.errors.add(:base, "Forbidden")
      end
    elsif role != "admin"
      unless course.status == "published"
        course.errors.add(:base, "Forbidden")
      end
    end
    course
  end

  def create(attributes)
    attributes = attributes.dup
    attributes[:status] ||= "draft"
    attributes[:price_cents] ||= 0
    attributes[:currency] ||= "USD"
    attributes[:enrollments_count] = 0
    if Thread.current[:user_role] == "instructor"
      attributes[:instructor_id] = Thread.current[:user_id]
    end
    repository.create(attributes)
  end

  def update(id, attributes)
    course = repository.find(id)
    if Thread.current[:user_role] == "instructor" && course.instructor_id != Thread.current[:user_id]
      course.errors.add(:base, "Forbidden")
      return course
    end
    repository.update(id, attributes)
  end

  def destroy(id)
    course = repository.find(id)
    if Thread.current[:user_role] == "instructor"
      if course.instructor_id != Thread.current[:user_id]
        course.errors.add(:base, "Forbidden")
        return course
      end
      if course.status != "draft"
        course.errors.add(:base, "Can only delete draft courses")
        return course
      end
    end
    if EnrollmentRecord.where(course_id: id).exists?
      course.errors.add(:base, "Cannot delete course with enrollments")
      return course
    end
    CourseRecord.find(id).destroy!
    course
  rescue ActiveRecord::RecordNotDestroyed
    course.errors.add(:base, "Cannot delete course with enrollments")
    course
  end

  def perform_transition(id, transition_name)
    entity = super
    return entity if entity.errors.any?

    case transition_name.to_sym
    when :publish
      repository.update(id, published_at: Time.current)
      entity = repository.find(id)
      NotificationRecord.create!(
        instructor_id: entity.instructor_id,
        event_type: "publish",
        title: "Course #{entity.title} published"
      )
    end

    entity
  end

  private

  def repository = @repository ||= CourseRepository.new

  def guard_transition(entity, transition_name)
    case transition_name.to_sym
    when :publish
      guard_publish(entity)
    when :archive
      guard_own(entity)
    end
  end

  def guard_own(entity)
    if Thread.current[:user_role] == "instructor" && entity.instructor_id != Thread.current[:user_id]
      entity.errors.add(:base, "Forbidden")
    end
  end

  def guard_publish(entity)
    guard_own(entity)
    return if entity.errors.any?

    if entity.description.blank?
      entity.errors.add(:base, "Description can't be blank")
    end

    modules = ModuleRecord.where(course_id: entity.id)
    if modules.count == 0
      entity.errors.add(:base, "At least one module required")
    else
      modules.each do |mod|
        if LessonRecord.where(module_id: mod.id).count == 0
          entity.errors.add(:base, "Each module must have at least one lesson")
          break
        end
      end
    end

    org = OrganizationRecord.find(entity.organization_id)
    if org.max_courses.present?
      published_count = CourseRecord.where(organization_id: org.id, status: "published").count
      if published_count >= org.max_courses
        entity.errors.add(:base, "Organization course limit reached")
      end
    end
  end
end
