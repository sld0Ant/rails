class LessonProgressService < ApplicationService
  def list_all(**params)
    params.any? ? repository.paginate(**params) : repository.all
  end

  def find(id) = repository.find(id)

  def create(attributes)
    attributes = attributes.dup
    authorize_enrollment!(attributes[:enrollment_id])

    if LessonProgressRecord.where(enrollment_id: attributes[:enrollment_id], lesson_id: attributes[:lesson_id]).exists?
      entity = LessonProgress.new(**attributes)
      entity.errors.add(:base, "Lesson progress already exists")
      return entity
    end

    attributes[:status] = "started"
    attributes[:started_at] = Time.current
    repository.create(attributes)
  end

  def update(id, attributes)
    progress = repository.find(id)
    authorize_enrollment!(progress.enrollment_id)

    if progress.status == "completed"
      progress.errors.add(:base, "Cannot revert completed lesson")
      return progress
    end

    attrs = { status: "completed", completed_at: Time.current }
    result = repository.update(id, attrs)
    return result if result.errors.any?

    recalculate_progress(result.enrollment_id)
    result
  end

  private

  def repository = @repository ||= LessonProgressRepository.new

  def authorize_enrollment!(enrollment_id)
    return unless Thread.current[:user_role] == "student"
    enrollment = EnrollmentRecord.find_by(id: enrollment_id)
    return unless enrollment && enrollment.student_id != Thread.current[:user_id]

    raise ActiveRecord::RecordNotFound
  end

  def recalculate_progress(enrollment_id)
    enrollment = EnrollmentRecord.find(enrollment_id)
    course = CourseRecord.find(enrollment.course_id)

    total = LessonRecord
      .joins("INNER JOIN modules ON modules.id = lessons.module_id")
      .where(modules: { course_id: course.id })
      .count

    return if total == 0

    completed = LessonProgressRecord
      .where(enrollment_id: enrollment_id, status: "completed")
      .count

    progress = (completed * 100) / total
    EnrollmentRecord.where(id: enrollment_id).update_all(progress_percent: progress)

    if progress == 100
      auto_complete_enrollment(enrollment)
    end
  end

  def auto_complete_enrollment(enrollment)
    now = Time.current
    EnrollmentRecord.where(id: enrollment.id, status: "active")
      .update_all(status: "completed", completed_at: now)

    cert_number = SecureRandom.uuid
    CertificateRecord.create!(
      enrollment_id: enrollment.id,
      certificate_number: cert_number,
      issued_at: now
    )

    course = CourseRecord.find(enrollment.course_id)
    NotificationRecord.create!(
      student_id: enrollment.student_id,
      event_type: "certificate",
      title: "Certificate issued for #{course.title}"
    )
  end
end
