class ModuleService < ApplicationService
  def list_all(**params)
    role = Thread.current[:user_role]
    if role == "student"
      params[:filter] ||= {}
      enrolled_course_ids = enrolled_course_ids_for_student
      if params[:filter]["course_id"].present?
        unless enrolled_course_ids.include?(params[:filter]["course_id"].to_i)
          return { data: [], meta: { page: 1, per: 50, total: 0 } }
        end
      else
        params[:filter]["course_id"] = enrolled_course_ids
      end
    elsif role == "guest" || role.nil?
      published_course_ids = CourseRecord.where(status: "published").pluck(:id)
      params[:filter] = (params[:filter] || {}).merge("course_id" => published_course_ids)
    end
    params.any? ? repository.paginate(**params) : repository.all
  end

  def find(id) = repository.find(id)
  def create(attributes) = guard_course_owner(attributes[:course_id]) { repository.create(attributes) }
  def update(id, attributes) = guard_course_owner(ModuleRecord.find(id).course_id) { repository.update(id, attributes) }

  def destroy(id)
    guard_course_owner(ModuleRecord.find(id).course_id) do
      repository.destroy(id)
      CourseModule.new(id: id)
    end
  end

  private

  def repository = @repository ||= ModuleRepository.new

  def enrolled_course_ids_for_student
    EnrollmentRecord
      .where(student_id: Thread.current[:user_id], status: %w[active completed])
      .pluck(:course_id)
  end

  def guard_course_owner(course_id)
    if Thread.current[:user_role] == "instructor"
      course = CourseRecord.find(course_id)
      unless course.instructor_id == Thread.current[:user_id]
        entity = CourseModule.new
        entity.errors.add(:base, "Forbidden")
        return entity
      end
    end
    yield
  end
end
