class ReviewService < ApplicationService
  def list_all(**params)
    role = Thread.current[:user_role]
    if role == "guest" || role.nil?
      published_course_ids = CourseRecord.where(status: "published").pluck(:id)
      params[:filter] = (params[:filter] || {}).merge("course_id" => published_course_ids)
    end
    params.any? ? repository.paginate(**params) : repository.all
  end

  def find(id) = repository.find(id)

  def create(attributes)
    attributes = attributes.dup
    if Thread.current[:user_role] == "student"
      attributes[:student_id] = Thread.current[:user_id]
    end

    review = Review.new(**attributes)

    enrolled = EnrollmentRecord.where(
      course_id: attributes[:course_id],
      student_id: attributes[:student_id],
      status: %w[active completed]
    ).exists?
    unless enrolled
      review.errors.add(:base, "Must be enrolled to review")
      return review
    end

    if ReviewRecord.where(course_id: attributes[:course_id], student_id: attributes[:student_id]).exists?
      review.errors.add(:base, "Already reviewed this course")
      return review
    end

    result = repository.create(attributes)
    recalculate_average_rating(attributes[:course_id]) if result.errors.empty?
    result
  end

  def update(id, attributes)
    review = repository.find(id)
    if Thread.current[:user_role] == "student" && review.student_id != Thread.current[:user_id]
      review.errors.add(:base, "Forbidden")
      return review
    end
    result = repository.update(id, attributes)
    recalculate_average_rating(result.course_id) if result.errors.empty?
    result
  end

  def destroy(id)
    review = repository.find(id)
    if Thread.current[:user_role] == "student" && review.student_id != Thread.current[:user_id]
      review.errors.add(:base, "Forbidden")
      return review
    end
    course_id = review.course_id
    repository.destroy(id)
    recalculate_average_rating(course_id)
    review
  end

  private

  def repository = @repository ||= ReviewRepository.new

  def recalculate_average_rating(course_id)
    avg = ReviewRecord.where(course_id: course_id).average(:rating)
    CourseRecord.where(id: course_id).update_all(average_rating: avg)
  end
end
