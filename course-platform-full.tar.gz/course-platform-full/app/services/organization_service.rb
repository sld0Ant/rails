class OrganizationService < ApplicationService
  def list_all(**params)
    params.any? ? repository.paginate(**params) : repository.all
  end

  def find(id) = repository.find(id)

  def create(attributes)
    limits = Organization::PLAN_LIMITS[attributes[:plan]] || Organization::PLAN_LIMITS["free"]
    attributes = attributes.dup
    attributes[:max_courses] ||= limits[:max_courses]
    attributes[:max_students] ||= limits[:max_students]
    repository.create(attributes)
  end

  def update(id, attributes) = repository.update(id, attributes)

  def destroy(id)
    OrganizationRecord.find(id).destroy!
    Organization.new(id: id)
  rescue ActiveRecord::RecordNotDestroyed, ActiveRecord::DeleteRestrictionError
    org = repository.find(id)
    org.errors.add(:base, "Cannot delete organization with existing courses, instructors, or students")
    org
  end

  private

  def repository = @repository ||= OrganizationRepository.new
end
