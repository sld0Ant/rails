class CertificateService < ApplicationService
  def list_all(**params)
    role = Thread.current[:user_role]
    user_id = Thread.current[:user_id]
    if role == "student"
      enrollment_ids = EnrollmentRecord.where(student_id: user_id).pluck(:id)
      params[:filter] = (params[:filter] || {}).merge("enrollment_id" => enrollment_ids)
    elsif role == "instructor"
      course_ids = CourseRecord.where(instructor_id: user_id).pluck(:id)
      enrollment_ids = EnrollmentRecord.where(course_id: course_ids).pluck(:id)
      params[:filter] = (params[:filter] || {}).merge("enrollment_id" => enrollment_ids)
    end
    params.any? ? repository.paginate(**params) : repository.all
  end

  def find(id) = repository.find(id)

  def destroy(id)
    repository.destroy(id)
    Certificate.new(id: id)
  end

  private

  def repository = @repository ||= CertificateRepository.new
end
