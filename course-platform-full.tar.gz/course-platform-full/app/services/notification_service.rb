class NotificationService < ApplicationService
  def list_all(**params)
    role = Thread.current[:user_role]
    user_id = Thread.current[:user_id]
    unless role == "admin"
      if role == "instructor"
        params[:filter] = (params[:filter] || {}).merge("instructor_id" => user_id)
      elsif role == "student"
        params[:filter] = (params[:filter] || {}).merge("student_id" => user_id)
      end
    end
    params.any? ? repository.paginate(**params) : repository.all
  end

  def find(id)
    notification = repository.find(id)
    authorize_own!(notification)
    notification
  end

  def mark_read(id)
    notification = repository.find(id)
    authorize_own!(notification)
    return notification if notification.errors.any?

    NotificationRecord.where(id: id).update_all(read_at: Time.current) if notification.read_at.nil?
    repository.find(id)
  end

  private

  def repository = @repository ||= NotificationRepository.new

  def authorize_own!(notification)
    role = Thread.current[:user_role]
    return if role == "admin"

    user_id = Thread.current[:user_id]
    if role == "instructor" && notification.instructor_id != user_id
      notification.errors.add(:base, "Forbidden")
    elsif role == "student" && notification.student_id != user_id
      notification.errors.add(:base, "Forbidden")
    end
  end
end
