class InstructorService < ApplicationService
  def list_all(**params)
    params.any? ? repository.paginate(**params) : repository.all
  end

  def find(id) = repository.find(id)
  def create(attributes) = repository.create(attributes)

  def update(id, attributes)
    instructor = repository.find(id)
    if Thread.current[:user_role] == "instructor" && instructor.id != Thread.current[:user_id]
      instructor.errors.add(:base, "Forbidden")
      return instructor
    end
    repository.update(id, attributes)
  end

  def destroy(id)
    InstructorRecord.find(id).destroy!
    Instructor.new(id: id)
  rescue ActiveRecord::RecordNotDestroyed, ActiveRecord::DeleteRestrictionError
    instructor = repository.find(id)
    instructor.errors.add(:base, "Cannot delete instructor with existing courses")
    instructor
  end

  private

  def repository = @repository ||= InstructorRepository.new
end
