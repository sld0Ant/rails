class EnrollmentService < ApplicationService
  def list_all(**params)
    role = Thread.current[:user_role]
    user_id = Thread.current[:user_id]
    if role == "student"
      params[:filter] = (params[:filter] || {}).merge("student_id" => user_id)
    elsif role == "instructor"
      instructor_course_ids = CourseRecord.where(instructor_id: user_id).pluck(:id)
      params[:filter] = (params[:filter] || {}).merge("course_id" => instructor_course_ids)
    end
    params.any? ? repository.paginate(**params) : repository.all
  end

  def find(id)
    enrollment = repository.find(id)
    authorize_read!(enrollment)
    enrollment
  end

  def create(attributes)
    attributes = attributes.dup
    if Thread.current[:user_role] == "student"
      attributes[:student_id] = Thread.current[:user_id]
    end

    enrollment = Enrollment.new(**attributes.merge(status: "active", progress_percent: 0))

    course = CourseRecord.find_by(id: attributes[:course_id])
    unless course
      enrollment.errors.add(:base, "Course not found")
      return enrollment
    end

    unless course.status == "published"
      enrollment.errors.add(:base, "Course is not published")
      return enrollment
    end

    existing = EnrollmentRecord.where(
      course_id: attributes[:course_id],
      student_id: attributes[:student_id],
      status: %w[active completed]
    ).exists?
    if existing
      enrollment.errors.add(:base, "Already enrolled")
      return enrollment
    end

    if course.max_students.present? && course.enrollments_count >= course.max_students
      enrollment.errors.add(:base, "Course is full")
      return enrollment
    end

    org = OrganizationRecord.find(course.organization_id)
    if org.max_students.present?
      unique_students = EnrollmentRecord
        .joins(:course)
        .where(courses: { organization_id: org.id }, status: %w[active completed])
        .distinct.count(:student_id)
      existing_student = EnrollmentRecord
        .joins(:course)
        .where(courses: { organization_id: org.id }, student_id: attributes[:student_id], status: %w[active completed])
        .exists?
      if !existing_student && unique_students >= org.max_students
        enrollment.errors.add(:base, "Organization student limit reached")
        return enrollment
      end
    end

    attributes[:status] = "active"
    attributes[:progress_percent] = 0
    attributes[:enrolled_at] = Time.current
    result = repository.create(attributes)
    return result if result.errors.any?

    CourseRecord.where(id: result.course_id)
      .update_all("enrollments_count = enrollments_count + 1")

    NotificationRecord.create!(
      student_id: result.student_id,
      event_type: "enrollment",
      title: "Enrolled in #{course.title}"
    )

    result
  end

  def perform_transition(id, transition_name)
    entity = super
    return entity if entity.errors.any?

    if transition_name.to_sym == :cancel
      CourseRecord.where(id: entity.course_id)
        .update_all("enrollments_count = enrollments_count - 1")
    end

    entity
  end

  private

  def repository = @repository ||= EnrollmentRepository.new

  def guard_transition(entity, transition_name)
    case transition_name.to_sym
    when :cancel
      if Thread.current[:user_role] == "student" && entity.student_id != Thread.current[:user_id]
        entity.errors.add(:base, "Forbidden")
        return
      end
      if PaymentRecord.where(enrollment_id: entity.id, status: "confirmed").exists?
        entity.errors.add(:base, "Refund payment before cancelling")
      end
    end
  end

  def authorize_read!(enrollment)
    role = Thread.current[:user_role]
    return if role == "admin"

    user_id = Thread.current[:user_id]
    if role == "student" && enrollment.student_id != user_id
      enrollment.errors.add(:base, "Forbidden")
    elsif role == "instructor"
      course = CourseRecord.find_by(id: enrollment.course_id)
      unless course&.instructor_id == user_id
        enrollment.errors.add(:base, "Forbidden")
      end
    end
  end
end
