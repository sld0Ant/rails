#!/usr/bin/env ruby
require "net/http"
require "json"
require "uri"

BASE = "http://localhost:3000"

module API
  def self.request(method, path, role: nil, user_id: nil, body: nil)
    uri = URI("#{BASE}#{path}")
    klass = case method
            when :get    then Net::HTTP::Get
            when :post   then Net::HTTP::Post
            when :patch  then Net::HTTP::Patch
            when :delete then Net::HTTP::Delete
            end
    req = klass.new(uri)
    req["Content-Type"] = "application/json"
    req["X-User-Role"] = role.to_s if role
    req["X-User-Id"] = user_id.to_s if user_id
    req.body = body.to_json if body
    res = Net::HTTP.start(uri.hostname, uri.port) { |http| http.request(req) }
    body = res.body.to_s
    [res.code.to_i, body.empty? ? nil : JSON.parse(body)]
  rescue JSON::ParserError
    [res.code.to_i, body]
  end

  def self.get(path, **opts)    = request(:get, path, **opts)
  def self.post(path, **opts)   = request(:post, path, **opts)
  def self.patch(path, **opts)  = request(:patch, path, **opts)
  def self.delete(path, **opts) = request(:delete, path, **opts)
end

class TestRunner
  attr_reader :pass, :fail, :errors

  def initialize
    @pass = 0
    @fail = 0
    @errors = []
    @group = nil
    @ids = {}
  end

  def group(name)
    @group = name
    puts "\n\e[1;36m━━━ #{name} ━━━\e[0m"
  end

  def assert(label, condition, detail = nil)
    full = @group ? "#{@group} / #{label}" : label
    if condition
      @pass += 1
      puts "  \e[32m✓\e[0m #{label}"
    else
      @fail += 1
      msg = detail ? "#{full}: #{detail}" : full
      @errors << msg
      puts "  \e[31m✗ #{label}\e[0m"
      puts "    \e[33m#{detail}\e[0m" if detail
    end
  end

  def assert_status(label, expected, actual_code, body = nil)
    assert(label, expected == actual_code,
      "expected HTTP #{expected}, got #{actual_code}" + (body ? " — #{truncate(body)}" : ""))
  end

  def assert_body(label, code, body, field_path, expected)
    val = dig_body(body, field_path)
    assert("#{label} → #{field_path}=#{expected.inspect}", val == expected,
      "got #{val.inspect} at #{field_path}")
  end

  def assert_error(label, code, body, pattern)
    json = body.is_a?(Hash) ? body.to_json : body.to_s
    assert(label, json.include?(pattern.to_s),
      "expected error containing '#{pattern}', got: #{truncate(json)}")
  end

  def store(key, val)
    @ids[key] = val
  end

  def id(key) = @ids.fetch(key)

  def summary
    puts "\n\e[1m#{"═" * 50}\e[0m"
    total = @pass + @fail
    if @fail == 0
      puts "\e[1;32m  ALL #{total} CHECKS PASSED ✓\e[0m"
    else
      puts "\e[1;31m  #{@fail} FAILED\e[0m / \e[32m#{@pass} passed\e[0m / #{total} total"
      puts "\n\e[1;31m  Failures:\e[0m"
      @errors.each { |e| puts "    \e[31m• #{e}\e[0m" }
    end
    puts "\e[1m#{"═" * 50}\e[0m"
    @fail
  end

  private

  def dig_body(body, path)
    keys = path.split(".")
    keys.reduce(body) { |obj, k| obj.is_a?(Hash) ? obj[k] : nil }
  end

  def truncate(s, max = 120)
    s = s.to_s
    s.length > max ? s[0..max] + "…" : s
  end
end

# ─────────────────────────────────────────────
t = TestRunner.new

# ══════════════════════════════════════════════
# PHASE 1: SEED DATA
# ══════════════════════════════════════════════
t.group "Phase 1: Seed data"

# Organizations with different plans
code, body = API.post("/organizations", role: :admin, body: { organization: { name: "Free School", slug: "free-school", plan: "free" } })
t.assert_status("create org (free)", 201, code); t.store(:org_free, body["id"])
t.assert_body("free plan limits", code, body, "max_courses", 3)
t.assert_body("free plan limits", code, body, "max_students", 100)

code, body = API.post("/organizations", role: :admin, body: { organization: { name: "Pro School", slug: "pro-school", plan: "pro" } })
t.assert_status("create org (pro)", 201, code); t.store(:org_pro, body["id"])
t.assert_body("pro plan limits", code, body, "max_courses", 50)
t.assert_body("pro plan limits", code, body, "max_students", 5000)

code, body = API.post("/organizations", role: :admin, body: { organization: { name: "Enterprise", slug: "enterprise", plan: "enterprise" } })
t.assert_status("create org (enterprise)", 201, code); t.store(:org_ent, body["id"])
t.assert_body("enterprise no limit", code, body, "max_courses", nil)
t.assert_body("enterprise no limit", code, body, "max_students", nil)

# Categories (test nesting)
code, body = API.post("/categories", role: :admin, body: { category: { name: "Tech", slug: "tech", position: 1 } })
t.assert_status("create root category", 201, code); t.store(:cat_root, body["id"])

code, body = API.post("/categories", role: :admin, body: { category: { name: "Web", slug: "web", position: 1, parent_id: t.id(:cat_root) } })
t.assert_status("create child category", 201, code); t.store(:cat_child, body["id"])

# Instructors
code, body = API.post("/instructors", role: :admin, body: { instructor: { organization_id: t.id(:org_pro), name: "Instructor A", email: "inst-a@test.com" } })
t.assert_status("create instructor A", 201, code); t.store(:inst_a, body["id"])

code, body = API.post("/instructors", role: :admin, body: { instructor: { organization_id: t.id(:org_pro), name: "Instructor B", email: "inst-b@test.com" } })
t.assert_status("create instructor B", 201, code); t.store(:inst_b, body["id"])

# Students
code, body = API.post("/students", role: :admin, body: { student: { organization_id: t.id(:org_pro), name: "Student 1", email: "s1@test.com" } })
t.assert_status("create student 1", 201, code); t.store(:stu1, body["id"])

code, body = API.post("/students", role: :admin, body: { student: { organization_id: t.id(:org_pro), name: "Student 2", email: "s2@test.com" } })
t.assert_status("create student 2", 201, code); t.store(:stu2, body["id"])

code, body = API.post("/students", role: :admin, body: { student: { organization_id: t.id(:org_pro), name: "Student 3", email: "s3@test.com" } })
t.assert_status("create student 3", 201, code); t.store(:stu3, body["id"])

# ══════════════════════════════════════════════
# PHASE 2: VALIDATION EDGE CASES
# ══════════════════════════════════════════════
t.group "Phase 2: Validation — missing required fields"

code, body = API.post("/organizations", role: :admin, body: { organization: { slug: "x" } })
t.assert_status("org without name → 422", 422, code)

code, body = API.post("/organizations", role: :admin, body: { organization: { name: "X", slug: "pro-school", plan: "pro" } })
t.assert_status("org duplicate slug → 500", 500, code)  # uniqueness at DB level

code, body = API.post("/organizations", role: :admin, body: { organization: { name: "X", slug: "x", plan: "invalid" } })
t.assert_status("org invalid plan → 422", 422, code)

code, body = API.post("/instructors", role: :admin, body: { instructor: { organization_id: t.id(:org_pro), name: "Bad", email: "not-an-email" } })
t.assert_status("instructor bad email → 422", 422, code)

code, body = API.post("/students", role: :admin, body: { student: { organization_id: t.id(:org_pro), name: "", email: "x@x.com" } })
t.assert_status("student blank name → 422", 422, code)

code, body = API.post("/courses", role: :admin, body: { course: { organization_id: t.id(:org_pro), instructor_id: t.id(:inst_a), title: "X", price_cents: -1 } })
t.assert_status("course negative price → 422", 422, code)

code, body = API.post("/courses", role: :admin, body: { course: { organization_id: t.id(:org_pro), instructor_id: t.id(:inst_a), title: "X", max_students: 0 } })
t.assert_status("course max_students=0 → 422", 422, code)

code, body = API.post("/courses", role: :admin, body: { course: { organization_id: t.id(:org_pro), instructor_id: t.id(:inst_a), title: "X", max_students: -5 } })
t.assert_status("course max_students=-5 → 422", 422, code)

code, body = API.post("/lessons", role: :admin, body: { lesson: { module_id: 999, title: "X", position: 0 } })
t.assert_status("lesson position=0 → 422", 422, code)

code, body = API.post("/lessons", role: :admin, body: { lesson: { module_id: 999, title: "X", lesson_type: "podcast" } })
t.assert_status("lesson invalid type → 422", 422, code)

code, body = API.post("/reviews", role: :admin, body: { review: { course_id: 1, student_id: 1, rating: 0 } })
t.assert_status("review rating=0 → 422", 422, code)

code, body = API.post("/reviews", role: :admin, body: { review: { course_id: 1, student_id: 1, rating: 6 } })
t.assert_status("review rating=6 → 422", 422, code)

# ══════════════════════════════════════════════
# PHASE 3: CATEGORY NESTING CONSTRAINT
# ══════════════════════════════════════════════
t.group "Phase 3: Category — max 1 level nesting"

code, body = API.post("/categories", role: :admin, body: { category: { name: "Deep", slug: "deep", position: 1, parent_id: t.id(:cat_child) } })
t.assert_status("3rd level nesting → 422", 422, code)
t.assert_error("nesting error message", code, body, "nest")

# ══════════════════════════════════════════════
# PHASE 4: AUTHORIZATION MATRIX
# ══════════════════════════════════════════════
t.group "Phase 4A: Auth — gate level (role access)"

# Guest cannot create anything
code, _ = API.post("/organizations", role: :guest, body: { organization: { name: "X", slug: "x" } })
t.assert_status("guest create org → 403", 403, code)

code, _ = API.post("/courses", role: :guest, body: { course: { title: "X" } })
t.assert_status("guest create course → 403", 403, code)

code, _ = API.post("/enrollments", role: :guest, body: { enrollment: { course_id: 1 } })
t.assert_status("guest create enrollment → 403", 403, code)

# Student cannot create instructors, orgs, categories
code, _ = API.post("/instructors", role: :student, user_id: t.id(:stu1), body: { instructor: { name: "X" } })
t.assert_status("student create instructor → 403", 403, code)

code, _ = API.post("/categories", role: :student, user_id: t.id(:stu1), body: { category: { name: "X" } })
t.assert_status("student create category → 403", 403, code)

code, _ = API.post("/organizations", role: :student, user_id: t.id(:stu1), body: { organization: { name: "X" } })
t.assert_status("student create org → 403", 403, code)

# Instructor cannot create students, orgs
code, _ = API.post("/students", role: :instructor, user_id: t.id(:inst_a), body: { student: { name: "X" } })
t.assert_status("instructor create student → 403", 403, code)

code, _ = API.post("/organizations", role: :instructor, user_id: t.id(:inst_a), body: { organization: { name: "X" } })
t.assert_status("instructor create org → 403", 403, code)

# Coupon — admin only
code, _ = API.get("/coupons", role: :student, user_id: t.id(:stu1))
t.assert_status("student list coupons → 403", 403, code)

code, _ = API.get("/coupons", role: :instructor, user_id: t.id(:inst_a))
t.assert_status("instructor list coupons → 403", 403, code)

# Student cannot create course
code, _ = API.post("/courses", role: :student, user_id: t.id(:stu1), body: { course: { title: "X" } })
t.assert_status("student create course → 403", 403, code)

# Student cannot confirm/refund payment
code, _ = API.post("/payments/999/confirm", role: :student, user_id: t.id(:stu1), body: {})
t.assert_status("student confirm payment → 403", 403, code)

code, _ = API.post("/payments/999/refund", role: :student, user_id: t.id(:stu1), body: {})
t.assert_status("student refund payment → 403", 403, code)

# Instructor cannot create enrollment
code, _ = API.post("/enrollments", role: :instructor, user_id: t.id(:inst_a), body: { enrollment: { course_id: 1 } })
t.assert_status("instructor create enrollment → 403", 403, code)

t.group "Phase 4B: Auth — domain level (ownership)"

# Instructor A cannot update instructor B
code, body = API.patch("/instructors/#{t.id(:inst_b)}", role: :instructor, user_id: t.id(:inst_a), body: { instructor: { name: "Hacked" } })
t.assert_status("inst A update inst B → 422", 422, code)
t.assert_error("forbidden", code, body, "Forbidden")

# Student 1 cannot update student 2
code, body = API.patch("/students/#{t.id(:stu2)}", role: :student, user_id: t.id(:stu1), body: { student: { name: "Hacked" } })
t.assert_status("stu1 update stu2 → 422", 422, code)
t.assert_error("forbidden", code, body, "Forbidden")

# ══════════════════════════════════════════════
# PHASE 5: COURSE LIFECYCLE
# ══════════════════════════════════════════════
t.group "Phase 5: Course — lifecycle & publish guards"

# Create course as instructor A (auto-set instructor_id)
code, body = API.post("/courses", role: :instructor, user_id: t.id(:inst_a), body: {
  course: { organization_id: t.id(:org_pro), title: "Main Course", price_cents: 5000, currency: "USD" }
})
t.assert_status("create course (instructor)", 201, code); t.store(:course_main, body["id"])
t.assert_body("auto-set instructor_id", code, body, "instructor_id", t.id(:inst_a))
t.assert_body("default status=draft", code, body, "status", "draft")
t.assert_body("default price", code, body, "price_cents", 5000)

# Guard 1: publish without description
code, body = API.post("/courses/#{t.id(:course_main)}/publish", role: :instructor, user_id: t.id(:inst_a))
t.assert_status("publish no description → 422", 422, code)
t.assert_error("description error", code, body, "Description")

# Add description
API.patch("/courses/#{t.id(:course_main)}", role: :instructor, user_id: t.id(:inst_a), body: { course: { description: "Full desc" } })

# Guard 2: publish without modules
code, body = API.post("/courses/#{t.id(:course_main)}/publish", role: :instructor, user_id: t.id(:inst_a))
t.assert_status("publish no modules → 422", 422, code)
t.assert_error("module error", code, body, "module")

# Add module but no lessons
code, body = API.post("/modules", role: :instructor, user_id: t.id(:inst_a), body: { course_module: { course_id: t.id(:course_main), title: "Mod 1", position: 1 } })
t.assert_status("create module 1", 201, code); t.store(:mod1, body["id"])

# Guard 3: publish with module but no lessons
code, body = API.post("/courses/#{t.id(:course_main)}/publish", role: :instructor, user_id: t.id(:inst_a))
t.assert_status("publish empty module → 422", 422, code)
t.assert_error("lesson error", code, body, "lesson")

# Add lessons
code, body = API.post("/modules", role: :instructor, user_id: t.id(:inst_a), body: { course_module: { course_id: t.id(:course_main), title: "Mod 2", position: 2 } })
t.store(:mod2, body["id"])

lesson_ids = []
[t.id(:mod1), t.id(:mod2)].each_with_index do |mod_id, mi|
  3.times do |li|
    code, body = API.post("/lessons", role: :instructor, user_id: t.id(:inst_a), body: {
      lesson: { module_id: mod_id, title: "M#{mi+1}L#{li+1}", position: li+1, lesson_type: "text" }
    })
    t.assert_status("create lesson M#{mi+1}L#{li+1}", 201, code)
    lesson_ids << body["id"]
  end
end
t.store(:lesson_ids, lesson_ids)

# Instructor B cannot publish instructor A's course
code, body = API.post("/courses/#{t.id(:course_main)}/publish", role: :instructor, user_id: t.id(:inst_b))
t.assert_status("inst B publish inst A course → 422", 422, code)
t.assert_error("forbidden", code, body, "Forbidden")

# Now publish succeeds
code, body = API.post("/courses/#{t.id(:course_main)}/publish", role: :instructor, user_id: t.id(:inst_a))
t.assert_status("publish success", 200, code)
t.assert_body("status=published", code, body, "status", "published")
t.assert("published_at set", !body["published_at"].nil?)

# Cannot publish again (already published)
code, body = API.post("/courses/#{t.id(:course_main)}/publish", role: :instructor, user_id: t.id(:inst_a))
t.assert_status("re-publish → 422", 422, code)
t.assert_error("transition error", code, body, "cannot transition")

# Instructor B cannot update inst A's course
code, body = API.patch("/courses/#{t.id(:course_main)}", role: :instructor, user_id: t.id(:inst_b), body: { course: { title: "Hacked" } })
t.assert_status("inst B update inst A course → 422", 422, code)
t.assert_error("forbidden", code, body, "Forbidden")

# Instructor cannot delete published course
code, body = API.delete("/courses/#{t.id(:course_main)}", role: :instructor, user_id: t.id(:inst_a))
t.assert_status("delete published course → 422", 422, code)

# ══════════════════════════════════════════════
# PHASE 6: COURSE VISIBILITY
# ══════════════════════════════════════════════
t.group "Phase 6: Course visibility by role"

# Create a draft course by inst B
code, body = API.post("/courses", role: :instructor, user_id: t.id(:inst_b), body: {
  course: { organization_id: t.id(:org_pro), title: "Draft Course B", description: "test" }
})
t.store(:course_draft_b, body["id"])

# Guest sees only published courses
code, body = API.get("/courses", role: :guest)
published_titles = body["data"].map { |c| c["title"] }
t.assert("guest sees published courses", published_titles.include?("Main Course"))
t.assert("guest doesn't see drafts", !published_titles.include?("Draft Course B"))

# Student sees only published courses
code, body = API.get("/courses", role: :student, user_id: t.id(:stu1))
student_titles = body["data"].map { |c| c["title"] }
t.assert("student sees published", student_titles.include?("Main Course"))
t.assert("student doesn't see drafts", !student_titles.include?("Draft Course B"))

# Instructor sees all (own + published)
code, body = API.get("/courses", role: :instructor, user_id: t.id(:inst_b))
inst_titles = body["data"].map { |c| c["title"] }
t.assert("instructor sees all", inst_titles.include?("Main Course") && inst_titles.include?("Draft Course B"))

# Guest cannot show draft course
code, body = API.get("/courses/#{t.id(:course_draft_b)}", role: :guest)
t.assert_error("guest show draft → forbidden", code, body, "Forbidden")

# Instructor B can show own draft
code, body = API.get("/courses/#{t.id(:course_draft_b)}", role: :instructor, user_id: t.id(:inst_b))
t.assert_status("inst B show own draft → 200", 200, code)

# Instructor A cannot show inst B's draft
code, body = API.get("/courses/#{t.id(:course_draft_b)}", role: :instructor, user_id: t.id(:inst_a))
t.assert_error("inst A show inst B draft → forbidden", code, body, "Forbidden")

# ══════════════════════════════════════════════
# PHASE 7: ENROLLMENT — ALL GUARDS
# ══════════════════════════════════════════════
t.group "Phase 7: Enrollment guards"

# Cannot enroll in draft course
code, body = API.post("/enrollments", role: :student, user_id: t.id(:stu1), body: { enrollment: { course_id: t.id(:course_draft_b) } })
t.assert_status("enroll in draft → 422", 422, code)
t.assert_error("not published", code, body, "not published")

# Enroll student 1
code, body = API.post("/enrollments", role: :student, user_id: t.id(:stu1), body: { enrollment: { course_id: t.id(:course_main) } })
t.assert_status("enroll stu1", 201, code); t.store(:enroll1, body["id"])
t.assert_body("status=active", code, body, "status", "active")
t.assert_body("progress=0", code, body, "progress_percent", 0)
t.assert("enrolled_at set", !body["enrolled_at"].nil?)

# Auto-set student_id from X-User-Id
t.assert_body("auto-set student_id", code, body, "student_id", t.id(:stu1))

# Duplicate enrollment blocked
code, body = API.post("/enrollments", role: :student, user_id: t.id(:stu1), body: { enrollment: { course_id: t.id(:course_main) } })
t.assert_status("duplicate enroll → 422", 422, code)
t.assert_error("already enrolled", code, body, "Already enrolled")

# Verify enrollments_count
code, body = API.get("/courses/#{t.id(:course_main)}", role: :admin)
t.assert_body("enrollments_count=1", code, body, "enrollments_count", 1)

# Course with max_students=2
code, body = API.post("/courses", role: :admin, body: {
  course: { organization_id: t.id(:org_pro), instructor_id: t.id(:inst_a), title: "Small Class",
            description: "Limited", max_students: 2, price_cents: 0 }
})
t.store(:course_small, body["id"])
# Add module + lesson + publish
code, body = API.post("/modules", role: :admin, body: { course_module: { course_id: t.id(:course_small), title: "M", position: 1 } })
small_mod = body["id"]
API.post("/lessons", role: :admin, body: { lesson: { module_id: small_mod, title: "L", position: 1 } })
API.post("/courses/#{t.id(:course_small)}/publish", role: :admin)

API.post("/enrollments", role: :student, user_id: t.id(:stu1), body: { enrollment: { course_id: t.id(:course_small) } })
API.post("/enrollments", role: :student, user_id: t.id(:stu2), body: { enrollment: { course_id: t.id(:course_small) } })

# 3rd enrollment → full
code, body = API.post("/enrollments", role: :student, user_id: t.id(:stu3), body: { enrollment: { course_id: t.id(:course_small) } })
t.assert_status("course full → 422", 422, code)
t.assert_error("course full", code, body, "full")

# ══════════════════════════════════════════════
# PHASE 8: ENROLLMENT — CANCEL & RE-ENROLL
# ══════════════════════════════════════════════
t.group "Phase 8: Enrollment cancel & re-enroll"

# Enroll stu2 in main course
code, body = API.post("/enrollments", role: :student, user_id: t.id(:stu2), body: { enrollment: { course_id: t.id(:course_main) } })
t.assert_status("enroll stu2", 201, code); t.store(:enroll2, body["id"])

# Student 1 cannot cancel student 2's enrollment
code, body = API.post("/enrollments/#{t.id(:enroll2)}/cancel", role: :student, user_id: t.id(:stu1))
t.assert_status("stu1 cancel stu2 enroll → 422", 422, code)
t.assert_error("forbidden", code, body, "Forbidden")

# Cancel stu2 enrollment
code, body = API.post("/enrollments/#{t.id(:enroll2)}/cancel", role: :student, user_id: t.id(:stu2))
t.assert_status("cancel stu2 → 200", 200, code)
t.assert_body("status=cancelled", code, body, "status", "cancelled")

# Verify enrollments_count decremented
code, body = API.get("/courses/#{t.id(:course_main)}", role: :admin)
t.assert_body("enrollments_count=1 after cancel", code, body, "enrollments_count", 1)

# Cannot cancel already cancelled
code, body = API.post("/enrollments/#{t.id(:enroll2)}/cancel", role: :student, user_id: t.id(:stu2))
t.assert_status("cancel cancelled → 422", 422, code)

# Re-enroll after cancel
code, body = API.post("/enrollments", role: :student, user_id: t.id(:stu2), body: { enrollment: { course_id: t.id(:course_main) } })
t.assert_status("re-enroll after cancel → 201", 201, code); t.store(:enroll2b, body["id"])

code, body = API.get("/courses/#{t.id(:course_main)}", role: :admin)
t.assert_body("enrollments_count=2 after re-enroll", code, body, "enrollments_count", 2)

# ══════════════════════════════════════════════
# PHASE 9: PAYMENT — ALL BUSINESS RULES
# ══════════════════════════════════════════════
t.group "Phase 9A: Payment — coupons & edge cases"

# Create coupons
code, body = API.post("/coupons", role: :admin, body: {
  coupon: { code: "HALF", discount_type: "percent", discount_value: 50, max_uses: 2,
            starts_at: "2025-01-01T00:00:00Z", expires_at: "2027-12-31T23:59:59Z" }
})
t.assert_status("create coupon HALF", 201, code); t.store(:coupon_half, body["id"])

code, body = API.post("/coupons", role: :admin, body: {
  coupon: { code: "FULL", discount_type: "percent", discount_value: 100,
            starts_at: "2025-01-01T00:00:00Z", expires_at: "2027-12-31T23:59:59Z" }
})
t.assert_status("create coupon FULL (100%)", 201, code); t.store(:coupon_full, body["id"])

code, body = API.post("/coupons", role: :admin, body: {
  coupon: { code: "FIXED500", discount_type: "fixed", discount_value: 500, currency: "USD",
            starts_at: "2025-01-01T00:00:00Z", expires_at: "2027-12-31T23:59:59Z" }
})
t.assert_status("create coupon FIXED500", 201, code); t.store(:coupon_fixed, body["id"])

code, body = API.post("/coupons", role: :admin, body: {
  coupon: { code: "EXPIRED", discount_type: "percent", discount_value: 10,
            starts_at: "2020-01-01T00:00:00Z", expires_at: "2020-12-31T23:59:59Z" }
})
t.assert_status("create expired coupon", 201, code); t.store(:coupon_expired, body["id"])

code, body = API.post("/coupons", role: :admin, body: {
  coupon: { code: "EURONLY", discount_type: "fixed", discount_value: 100, currency: "EUR",
            starts_at: "2025-01-01T00:00:00Z", expires_at: "2027-12-31T23:59:59Z" }
})
t.assert_status("create EUR coupon", 201, code); t.store(:coupon_eur, body["id"])

code, body = API.post("/coupons", role: :admin, body: {
  coupon: { code: "MINPURCHASE", discount_type: "percent", discount_value: 10,
            min_purchase_cents: 10000,
            starts_at: "2025-01-01T00:00:00Z", expires_at: "2027-12-31T23:59:59Z" }
})
t.assert_status("create min_purchase coupon", 201, code); t.store(:coupon_minp, body["id"])

# Payment with 50% coupon
code, body = API.post("/payments", role: :student, user_id: t.id(:stu1), body: {
  payment: { enrollment_id: t.id(:enroll1), coupon_id: t.id(:coupon_half) }
})
t.assert_status("payment with 50% coupon", 201, code); t.store(:pay1, body["id"])
t.assert_body("amount=5000", code, body, "amount_cents", 5000)
t.assert_body("net=2500", code, body, "net_amount_cents", 2500)
t.assert_body("status=pending", code, body, "status", "pending")

# Duplicate payment blocked
code, body = API.post("/payments", role: :student, user_id: t.id(:stu1), body: {
  payment: { enrollment_id: t.id(:enroll1) }
})
t.assert_status("duplicate payment → 422", 422, code)
t.assert_error("active payment exists", code, body, "Active payment already exists")

# Coupon used_count incremented
code, body = API.get("/coupons/#{t.id(:coupon_half)}", role: :admin)
t.assert_body("coupon used_count=1", code, body, "used_count", 1)

t.group "Phase 9B: Payment — coupon validation failures"

# Expired coupon
code, body = API.post("/payments", role: :student, user_id: t.id(:stu2), body: {
  payment: { enrollment_id: t.id(:enroll2b), coupon_id: t.id(:coupon_expired) }
})
t.assert_status("expired coupon → 422", 422, code)
t.assert_error("expired error", code, body, "expired")

# Currency mismatch (EUR coupon on USD course)
code, body = API.post("/payments", role: :student, user_id: t.id(:stu2), body: {
  payment: { enrollment_id: t.id(:enroll2b), coupon_id: t.id(:coupon_eur) }
})
t.assert_status("currency mismatch → 422", 422, code)
t.assert_error("currency error", code, body, "currency")

# Min purchase not met (course is 5000, min is 10000)
code, body = API.post("/payments", role: :student, user_id: t.id(:stu2), body: {
  payment: { enrollment_id: t.id(:enroll2b), coupon_id: t.id(:coupon_minp) }
})
t.assert_status("min purchase not met → 422", 422, code)
t.assert_error("min purchase error", code, body, "inimum purchase")

t.group "Phase 9C: Payment — auto-confirm on 100% discount"

code, body = API.post("/payments", role: :student, user_id: t.id(:stu2), body: {
  payment: { enrollment_id: t.id(:enroll2b), coupon_id: t.id(:coupon_full) }
})
t.assert_status("100% coupon → 201", 201, code); t.store(:pay2_auto, body["id"])
t.assert_body("net=0", code, body, "net_amount_cents", 0)
t.assert_body("auto-confirmed", code, body, "status", "confirmed")
t.assert("paid_at auto-set", !body["paid_at"].nil?)

t.group "Phase 9D: Payment — confirm & refund lifecycle"

# Confirm pay1
code, body = API.post("/payments/#{t.id(:pay1)}/confirm", role: :admin)
t.assert_status("confirm payment", 200, code)
t.assert_body("status=confirmed", code, body, "status", "confirmed")
t.assert("paid_at set", !body["paid_at"].nil?)

# Cannot confirm again (already confirmed)
code, body = API.post("/payments/#{t.id(:pay1)}/confirm", role: :admin)
t.assert_status("re-confirm → 422", 422, code)

# Refund
code, body = API.post("/payments/#{t.id(:pay1)}/refund", role: :admin)
t.assert_status("refund payment", 200, code)
t.assert_body("status=refunded", code, body, "status", "refunded")
t.assert("refunded_at set", !body["refunded_at"].nil?)

# Cannot refund again
code, body = API.post("/payments/#{t.id(:pay1)}/refund", role: :admin)
t.assert_status("re-refund → 422", 422, code)

# Coupon count restored
code, body = API.get("/coupons/#{t.id(:coupon_half)}", role: :admin)
t.assert_body("coupon used_count=0 after refund", code, body, "used_count", 0)

t.group "Phase 9E: Payment — free course blocked"

# Create free course
code, body = API.post("/courses", role: :admin, body: {
  course: { organization_id: t.id(:org_pro), instructor_id: t.id(:inst_a), title: "Free Course",
            description: "Free", price_cents: 0 }
})
t.store(:course_free, body["id"])
code, body = API.post("/modules", role: :admin, body: { course_module: { course_id: t.id(:course_free), title: "M", position: 1 } })
free_mod = body["id"]
API.post("/lessons", role: :admin, body: { lesson: { module_id: free_mod, title: "L", position: 1 } })
API.post("/courses/#{t.id(:course_free)}/publish", role: :admin)

code, body = API.post("/enrollments", role: :student, user_id: t.id(:stu3), body: { enrollment: { course_id: t.id(:course_free) } })
t.store(:enroll_free, body["id"])

code, body = API.post("/payments", role: :student, user_id: t.id(:stu3), body: { payment: { enrollment_id: t.id(:enroll_free) } })
t.assert_status("payment for free course → 422", 422, code)
t.assert_error("course is free", code, body, "Course is free")

# ══════════════════════════════════════════════
# PHASE 10: CANCEL WITH CONFIRMED PAYMENT
# ══════════════════════════════════════════════
t.group "Phase 10: Cancel enrollment with confirmed payment"

# stu1 has enroll1 with refunded payment — should be able to cancel now
# But first let's make a new confirmed payment
code, body = API.post("/payments", role: :student, user_id: t.id(:stu1), body: { payment: { enrollment_id: t.id(:enroll1) } })
t.assert_status("new payment for stu1", 201, code); t.store(:pay1b, body["id"])

API.post("/payments/#{t.id(:pay1b)}/confirm", role: :admin)

code, body = API.post("/enrollments/#{t.id(:enroll1)}/cancel", role: :student, user_id: t.id(:stu1))
t.assert_status("cancel with confirmed payment → 422", 422, code)
t.assert_error("refund first", code, body, "Refund payment before cancelling")

# Refund, then cancel
API.post("/payments/#{t.id(:pay1b)}/refund", role: :admin)
code, body = API.post("/enrollments/#{t.id(:enroll1)}/cancel", role: :student, user_id: t.id(:stu1))
t.assert_status("cancel after refund → 200", 200, code)

# ══════════════════════════════════════════════
# PHASE 11: LESSON PROGRESS & AUTO-COMPLETION
# ══════════════════════════════════════════════
t.group "Phase 11: Lesson progress & auto-completion"

# Use stu2's enrollment (enroll2b)
lessons = t.id(:lesson_ids)

# Complete 5 of 6 lessons
5.times do |i|
  code, body = API.post("/lesson_progresses", role: :student, user_id: t.id(:stu2), body: {
    lesson_progress: { enrollment_id: t.id(:enroll2b), lesson_id: lessons[i] }
  })
  t.assert_status("start lesson #{i+1}", 201, code)
  lp_id = body["id"]

  code, body = API.patch("/lesson_progresses/#{lp_id}", role: :student, user_id: t.id(:stu2), body: {
    lesson_progress: { status: "completed" }
  })
  t.assert_status("complete lesson #{i+1}", 200, code)
end

# Check progress at 83% (5/6)
code, body = API.get("/enrollments/#{t.id(:enroll2b)}", role: :admin)
t.assert_body("progress=83%", code, body, "progress_percent", 83)
t.assert_body("still active", code, body, "status", "active")

# Duplicate lesson progress blocked
code, body = API.post("/lesson_progresses", role: :student, user_id: t.id(:stu2), body: {
  lesson_progress: { enrollment_id: t.id(:enroll2b), lesson_id: lessons[0] }
})
t.assert_status("duplicate lesson progress → 422", 422, code)
t.assert_error("already exists", code, body, "already exists")

# Complete last lesson → 100% → auto-complete
code, body = API.post("/lesson_progresses", role: :student, user_id: t.id(:stu2), body: {
  lesson_progress: { enrollment_id: t.id(:enroll2b), lesson_id: lessons[5] }
})
lp_last = body["id"]
code, body = API.patch("/lesson_progresses/#{lp_last}", role: :student, user_id: t.id(:stu2), body: {
  lesson_progress: { status: "completed" }
})
t.assert_status("complete last lesson", 200, code)

# Verify auto-completion
code, body = API.get("/enrollments/#{t.id(:enroll2b)}", role: :admin)
t.assert_body("progress=100%", code, body, "progress_percent", 100)
t.assert_body("auto-completed", code, body, "status", "completed")
t.assert("completed_at set", !body["completed_at"].nil?)

# Certificate created
code, body = API.get("/certificates?filter[enrollment_id]=#{t.id(:enroll2b)}", role: :admin)
t.assert("certificate exists", body["data"].length == 1)
t.assert("certificate has UUID", body["data"][0]["certificate_number"]&.match?(/\A[0-9a-f-]{36}\z/))

# Cannot cancel completed enrollment
code, body = API.post("/enrollments/#{t.id(:enroll2b)}/cancel", role: :student, user_id: t.id(:stu2))
t.assert_status("cancel completed → 422", 422, code)

# Cannot revert completed lesson
first_lp = nil
code, body = API.get("/lesson_progresses?filter[enrollment_id]=#{t.id(:enroll2b)}&filter[lesson_id]=#{lessons[0]}", role: :admin)
first_lp = body["data"][0]["id"]
code, body = API.patch("/lesson_progresses/#{first_lp}", role: :student, user_id: t.id(:stu2), body: {
  lesson_progress: { status: "started" }
})
t.assert_status("revert completed lesson → 422", 422, code)
t.assert_error("cannot revert", code, body, "Cannot revert")

# ══════════════════════════════════════════════
# PHASE 12: REVIEWS
# ══════════════════════════════════════════════
t.group "Phase 12: Reviews & average rating"

# Student must be enrolled
code, body = API.post("/reviews", role: :student, user_id: t.id(:stu3), body: {
  review: { course_id: t.id(:course_main), rating: 5, body: "Great" }
})
t.assert_status("review without enrollment → 422", 422, code)
t.assert_error("must be enrolled", code, body, "enrolled")

# stu2 is enrolled (completed) — can review
code, body = API.post("/reviews", role: :student, user_id: t.id(:stu2), body: {
  review: { course_id: t.id(:course_main), rating: 4, body: "Good" }
})
t.assert_status("stu2 review → 201", 201, code); t.store(:review1, body["id"])

# Verify average rating
code, body = API.get("/courses/#{t.id(:course_main)}", role: :admin)
t.assert("avg rating = 4.0", body["average_rating"].to_f == 4.0)

# Duplicate review blocked
code, body = API.post("/reviews", role: :student, user_id: t.id(:stu2), body: {
  review: { course_id: t.id(:course_main), rating: 5 }
})
t.assert_status("duplicate review → 422", 422, code)

# Enroll stu3 for another review (re-enroll stu1 cancelled, use stu3 on another course... hmm)
# Let's enroll stu3 in main course
code, body = API.post("/enrollments", role: :student, user_id: t.id(:stu3), body: { enrollment: { course_id: t.id(:course_main) } })
t.assert_status("enroll stu3 in main", 201, code); t.store(:enroll3, body["id"])

code, body = API.post("/reviews", role: :student, user_id: t.id(:stu3), body: {
  review: { course_id: t.id(:course_main), rating: 2, body: "Meh" }
})
t.assert_status("stu3 review → 201", 201, code); t.store(:review2, body["id"])

# Average should be (4+2)/2 = 3.0
code, body = API.get("/courses/#{t.id(:course_main)}", role: :admin)
t.assert("avg rating = 3.0", body["average_rating"].to_f == 3.0)

# Student can update own review
code, body = API.patch("/reviews/#{t.id(:review2)}", role: :student, user_id: t.id(:stu3), body: { review: { rating: 5 } })
t.assert_status("update own review → 200", 200, code)

# Average should be (4+5)/2 = 4.5
code, body = API.get("/courses/#{t.id(:course_main)}", role: :admin)
t.assert("avg rating = 4.5 after update", body["average_rating"].to_f == 4.5)

# Student cannot update another's review
code, body = API.patch("/reviews/#{t.id(:review1)}", role: :student, user_id: t.id(:stu3), body: { review: { rating: 1 } })
t.assert_status("stu3 update stu2 review → 422", 422, code)

# Delete review → recalculate
code, body = API.delete("/reviews/#{t.id(:review2)}", role: :student, user_id: t.id(:stu3))
t.assert_status("delete own review → 204", 204, code)

code, body = API.get("/courses/#{t.id(:course_main)}", role: :admin)
t.assert("avg rating = 4.0 after delete", body["average_rating"].to_f == 4.0)

# ══════════════════════════════════════════════
# PHASE 13: ARCHIVE & POST-ARCHIVE BEHAVIOR
# ══════════════════════════════════════════════
t.group "Phase 13: Course archive"

code, body = API.post("/courses/#{t.id(:course_main)}/archive", role: :instructor, user_id: t.id(:inst_a))
t.assert_status("archive course → 200", 200, code)
t.assert_body("status=archived", code, body, "status", "archived")

# Cannot archive again (no transition from archived)
code, body = API.post("/courses/#{t.id(:course_main)}/archive", role: :instructor, user_id: t.id(:inst_a))
t.assert_status("re-archive → 422", 422, code)

# Cannot publish archived course
code, body = API.post("/courses/#{t.id(:course_main)}/publish", role: :instructor, user_id: t.id(:inst_a))
t.assert_status("publish archived → 422", 422, code)

# Cannot enroll in archived course
code, body = API.post("/enrollments", role: :student, user_id: t.id(:stu1), body: { enrollment: { course_id: t.id(:course_main) } })
t.assert_status("enroll archived → 422", 422, code)
t.assert_error("not published", code, body, "not published")

# Archive from draft (direct)
code, body = API.post("/courses/#{t.id(:course_draft_b)}/archive", role: :instructor, user_id: t.id(:inst_b))
t.assert_status("archive draft → 200", 200, code)
t.assert_body("status=archived", code, body, "status", "archived")

# ══════════════════════════════════════════════
# PHASE 14: COURSE DELETE GUARDS
# ══════════════════════════════════════════════
t.group "Phase 14: Course delete guards"

# Cannot delete course with enrollments
code, body = API.delete("/courses/#{t.id(:course_main)}", role: :admin)
t.assert_status("delete course with enrollments → 422", 422, code)
t.assert_error("has enrollments", code, body, "enrollments")

# Create deletable draft
code, body = API.post("/courses", role: :instructor, user_id: t.id(:inst_a), body: {
  course: { organization_id: t.id(:org_pro), title: "Deletable Draft" }
})
t.store(:course_del, body["id"])

# Instructor B cannot delete instructor A's draft
code, body = API.delete("/courses/#{t.id(:course_del)}", role: :instructor, user_id: t.id(:inst_b))
t.assert_status("inst B delete inst A draft → 422", 422, code)

# Instructor A can delete own draft
code, body = API.delete("/courses/#{t.id(:course_del)}", role: :instructor, user_id: t.id(:inst_a))
t.assert_status("inst A delete own draft → 204", 204, code)

# ══════════════════════════════════════════════
# PHASE 15: CASCADE & RESTRICT DELETE
# ══════════════════════════════════════════════
t.group "Phase 15: Cascade & restrict delete"

# Cannot delete org with data
code, body = API.delete("/organizations/#{t.id(:org_pro)}", role: :admin)
t.assert_status("delete org with data → 422", 422, code)

# Cannot delete instructor with courses
code, body = API.delete("/instructors/#{t.id(:inst_a)}", role: :admin)
t.assert_status("delete instructor with courses → 422", 422, code)

# Cannot delete student with enrollments
code, body = API.delete("/students/#{t.id(:stu2)}", role: :admin)
t.assert_status("delete student with enrollments → 422", 422, code)

# Category delete → nullify courses
code, body = API.post("/categories", role: :admin, body: { category: { name: "Temp", slug: "temp-del", position: 99 } })
temp_cat = body["id"]
code, body = API.post("/courses", role: :admin, body: {
  course: { organization_id: t.id(:org_pro), instructor_id: t.id(:inst_a), title: "Cat Test", category_id: temp_cat }
})
cat_course_id = body["id"]
t.assert_body("course has category", code, body, "category_id", temp_cat)

API.delete("/categories/#{temp_cat}", role: :admin)
code, body = API.get("/courses/#{cat_course_id}", role: :admin)
t.assert_body("course category nullified", code, body, "category_id", nil)

# Module delete → cascade lessons
code, body = API.post("/courses", role: :admin, body: {
  course: { organization_id: t.id(:org_pro), instructor_id: t.id(:inst_b), title: "Cascade Test" }
})
cascade_course = body["id"]
code, body = API.post("/modules", role: :admin, body: { course_module: { course_id: cascade_course, title: "CascMod", position: 1 } })
cascade_mod = body["id"]
code, body = API.post("/lessons", role: :admin, body: { lesson: { module_id: cascade_mod, title: "CascLesson", position: 1 } })
cascade_lesson = body["id"]

API.delete("/modules/#{cascade_mod}", role: :admin)
code, body = API.get("/lessons/#{cascade_lesson}", role: :admin)
t.assert_status("lesson cascaded with module → 404", 404, code)

# Cannot delete coupon with payments
code, body = API.delete("/coupons/#{t.id(:coupon_half)}", role: :admin)
t.assert_status("delete coupon with payments → 422", 422, code)

# ══════════════════════════════════════════════
# PHASE 16: NOTIFICATIONS
# ══════════════════════════════════════════════
t.group "Phase 16: Notifications — side effects & mark_read"

# Verify all expected notifications exist
code, body = API.get("/notifications", role: :admin)
events = body["data"].map { |n| n["event_type"] }
t.assert("has enrollment notifications", events.include?("enrollment"))
t.assert("has publish notifications", events.include?("publish"))
t.assert("has certificate notification", events.include?("certificate"))
t.assert("has payment notification", events.include?("payment"))

# Student can only see own notifications
code, body = API.get("/notifications", role: :student, user_id: t.id(:stu2))
body["data"].each do |n|
  t.assert("stu2 sees only own (id=#{n["id"]})", n["student_id"] == t.id(:stu2))
end

# Instructor sees only own
code, body = API.get("/notifications", role: :instructor, user_id: t.id(:inst_a))
body["data"].each do |n|
  t.assert("inst A sees only own (id=#{n["id"]})", n["instructor_id"] == t.id(:inst_a))
end

# Mark read
notif_id = body["data"][0]["id"]
code, body = API.patch("/notifications/#{notif_id}/mark_read", role: :instructor, user_id: t.id(:inst_a))
t.assert_status("mark_read → 200", 200, code)
t.assert("read_at set", !body["read_at"].nil?)

# Mark read idempotent
code, body = API.patch("/notifications/#{notif_id}/mark_read", role: :instructor, user_id: t.id(:inst_a))
t.assert_status("mark_read again → 200", 200, code)

# ══════════════════════════════════════════════
# PHASE 17: COLLECTION FEATURES
# ══════════════════════════════════════════════
t.group "Phase 17: Collection — pagination, sort, filter, search"

# Pagination
code, body = API.get("/notifications?per_page=2&page=1", role: :admin)
t.assert("pagination: 2 per page", body["data"].length <= 2)
t.assert("pagination meta", body["meta"]["per"] == 2)
t.assert("pagination total > 2", body["meta"]["total"] > 2)

# Sorting
code, body = API.get("/courses?sort=title", role: :admin)
if body["data"].length >= 2
  titles = body["data"].map { |c| c["title"] }
  t.assert("sorted by title", titles == titles.sort)
end

# Filtering
code, body = API.get("/courses?filter[status]=draft", role: :admin)
body["data"].each do |c|
  t.assert("filter status=draft (id=#{c["id"]})", c["status"] == "draft")
end

code, body = API.get("/enrollments?filter[status]=active", role: :admin)
body["data"].each do |e|
  t.assert("filter enrollment active (id=#{e["id"]})", e["status"] == "active")
end

# Search
code, body = API.get("/instructors?search=Instructor+A", role: :admin)
t.assert("search instructors", body["data"].any? { |i| i["name"] == "Instructor A" })

code, body = API.get("/courses?search=Main", role: :admin)
t.assert("search courses by title", body["data"].any? { |c| c["title"].include?("Main") })

# Filter by read
code, body = API.get("/notifications?filter[read]=true", role: :admin)
body["data"].each do |n|
  t.assert("filter read=true (id=#{n["id"]})", !n["read_at"].nil?)
end

code, body = API.get("/notifications?filter[read]=false", role: :admin)
body["data"].each do |n|
  t.assert("filter read=false (id=#{n["id"]})", n["read_at"].nil?)
end

# ══════════════════════════════════════════════
# PHASE 18: HATEOAS _links
# ══════════════════════════════════════════════
t.group "Phase 18: HATEOAS _links"

code, body = API.get("/courses/#{t.id(:course_free)}", role: :admin)
t.assert("has self link", body.dig("_links", "self")&.include?("/courses/"))
t.assert("has organization link", body.dig("_links", "organization")&.include?("/organizations/"))
t.assert("has instructor link", body.dig("_links", "instructor")&.include?("/instructors/"))

# Published course should have archive transition link
t.assert("has archive link", body.dig("_links", "archive", "method") == "POST")

# ══════════════════════════════════════════════
# PHASE 19: ORG PLAN LIMITS — FREE PLAN
# ══════════════════════════════════════════════
t.group "Phase 19: Organization plan limits (free plan)"

# Create instructor and student for free org
code, body = API.post("/instructors", role: :admin, body: { instructor: { organization_id: t.id(:org_free), name: "Free Inst", email: "free-inst@test.com" } })
t.store(:inst_free, body["id"])

# Create 3 courses and publish them (free plan limit)
3.times do |i|
  code, body = API.post("/courses", role: :admin, body: {
    course: { organization_id: t.id(:org_free), instructor_id: t.id(:inst_free),
              title: "Free Course #{i+1}", description: "Desc #{i+1}" }
  })
  cid = body["id"]
  code, body = API.post("/modules", role: :admin, body: { course_module: { course_id: cid, title: "M", position: 1 } })
  mid = body["id"]
  API.post("/lessons", role: :admin, body: { lesson: { module_id: mid, title: "L", position: 1 } })
  code, body = API.post("/courses/#{cid}/publish", role: :admin)
  t.assert_status("publish free org course #{i+1}", 200, code)
end

# 4th course should hit limit
code, body = API.post("/courses", role: :admin, body: {
  course: { organization_id: t.id(:org_free), instructor_id: t.id(:inst_free),
            title: "Free Course 4", description: "Desc 4" }
})
cid4 = body["id"]
code, body = API.post("/modules", role: :admin, body: { course_module: { course_id: cid4, title: "M", position: 1 } })
mid4 = body["id"]
API.post("/lessons", role: :admin, body: { lesson: { module_id: mid4, title: "L", position: 1 } })
code, body = API.post("/courses/#{cid4}/publish", role: :admin)
t.assert_status("free org 4th publish → 422", 422, code)
t.assert_error("limit reached", code, body, "limit")

# ══════════════════════════════════════════════
# PHASE 20: COUPON MAX USES
# ══════════════════════════════════════════════
t.group "Phase 20: Coupon max_uses exhaustion"

# HALF coupon has max_uses=2, currently used_count should be 0 (refunded)
# Create 2 more enrollments and use the coupon twice
# Use stu1 re-enroll in main (archived) — won't work. Use free course + paid course combo

# Actually let's create a fresh paid course for this test
code, body = API.post("/courses", role: :admin, body: {
  course: { organization_id: t.id(:org_pro), instructor_id: t.id(:inst_a),
            title: "Coupon Test Course", description: "Test", price_cents: 3000 }
})
t.store(:course_coupon, body["id"])
code, body = API.post("/modules", role: :admin, body: { course_module: { course_id: t.id(:course_coupon), title: "M", position: 1 } })
ct_mod = body["id"]
API.post("/lessons", role: :admin, body: { lesson: { module_id: ct_mod, title: "L", position: 1 } })
API.post("/courses/#{t.id(:course_coupon)}/publish", role: :admin)

# Enroll all 3 students
code, _ = API.post("/enrollments", role: :student, user_id: t.id(:stu1), body: { enrollment: { course_id: t.id(:course_coupon) } })
t.store(:enroll_ct1, _["id"])
code, _ = API.post("/enrollments", role: :student, user_id: t.id(:stu2), body: { enrollment: { course_id: t.id(:course_coupon) } })
t.store(:enroll_ct2, _["id"])
code, _ = API.post("/enrollments", role: :student, user_id: t.id(:stu3), body: { enrollment: { course_id: t.id(:course_coupon) } })
t.store(:enroll_ct3, _["id"])

# Use coupon twice (max_uses=2)
code, body = API.post("/payments", role: :student, user_id: t.id(:stu1), body: {
  payment: { enrollment_id: t.id(:enroll_ct1), coupon_id: t.id(:coupon_half) }
})
t.assert_status("coupon use 1/2", 201, code)
t.assert_body("50% off 3000 = 1500", code, body, "net_amount_cents", 1500)

code, body = API.post("/payments", role: :student, user_id: t.id(:stu2), body: {
  payment: { enrollment_id: t.id(:enroll_ct2), coupon_id: t.id(:coupon_half) }
})
t.assert_status("coupon use 2/2", 201, code)

# 3rd use → exhausted
code, body = API.post("/payments", role: :student, user_id: t.id(:stu3), body: {
  payment: { enrollment_id: t.id(:enroll_ct3), coupon_id: t.id(:coupon_half) }
})
t.assert_status("coupon exhausted → 422", 422, code)
t.assert_error("usage limit", code, body, "limit")

# ══════════════════════════════════════════════
# PHASE 21: FIXED AMOUNT COUPON
# ══════════════════════════════════════════════
t.group "Phase 21: Fixed amount coupon"

# FIXED500 coupon: $5 off a $30 course
# Need a fresh enrollment
code, body = API.post("/courses", role: :admin, body: {
  course: { organization_id: t.id(:org_pro), instructor_id: t.id(:inst_a),
            title: "Fixed Coupon Test", description: "Test", price_cents: 1000 }
})
t.store(:course_fixed, body["id"])
code, body = API.post("/modules", role: :admin, body: { course_module: { course_id: t.id(:course_fixed), title: "M", position: 1 } })
ft_mod = body["id"]
API.post("/lessons", role: :admin, body: { lesson: { module_id: ft_mod, title: "L", position: 1 } })
API.post("/courses/#{t.id(:course_fixed)}/publish", role: :admin)

code, body = API.post("/enrollments", role: :student, user_id: t.id(:stu1), body: { enrollment: { course_id: t.id(:course_fixed) } })
t.store(:enroll_fixed, body["id"])

# Fixed $5 off $10 course = $5
code, body = API.post("/payments", role: :student, user_id: t.id(:stu1), body: {
  payment: { enrollment_id: t.id(:enroll_fixed), coupon_id: t.id(:coupon_fixed) }
})
t.assert_status("fixed coupon payment", 201, code)
t.assert_body("1000 - 500 = 500", code, body, "net_amount_cents", 500)

# Fixed coupon > course price → net = 0, auto-confirm
code, body = API.post("/courses", role: :admin, body: {
  course: { organization_id: t.id(:org_pro), instructor_id: t.id(:inst_a),
            title: "Cheap Course", description: "Test", price_cents: 200 }
})
t.store(:course_cheap, body["id"])
code, body = API.post("/modules", role: :admin, body: { course_module: { course_id: t.id(:course_cheap), title: "M", position: 1 } })
ch_mod = body["id"]
API.post("/lessons", role: :admin, body: { lesson: { module_id: ch_mod, title: "L", position: 1 } })
API.post("/courses/#{t.id(:course_cheap)}/publish", role: :admin)

code, body = API.post("/enrollments", role: :student, user_id: t.id(:stu2), body: { enrollment: { course_id: t.id(:course_cheap) } })
t.store(:enroll_cheap, body["id"])

code, body = API.post("/payments", role: :student, user_id: t.id(:stu2), body: {
  payment: { enrollment_id: t.id(:enroll_cheap), coupon_id: t.id(:coupon_fixed) }
})
t.assert_status("fixed coupon > price → auto-confirm", 201, code)
t.assert_body("net clamped to 0", code, body, "net_amount_cents", 0)
t.assert_body("auto-confirmed", code, body, "status", "confirmed")

# ══════════════════════════════════════════════
# PHASE 22: DATA INTEGRITY CHECK
# ══════════════════════════════════════════════
t.group "Phase 22: Data integrity — final counters"

# Check all coupon used_counts are consistent
code, body = API.get("/coupons/#{t.id(:coupon_half)}", role: :admin)
t.assert_body("HALF used_count=2", code, body, "used_count", 2)

code, body = API.get("/coupons/#{t.id(:coupon_full)}", role: :admin)
t.assert_body("FULL used_count=1", code, body, "used_count", 1)

code, body = API.get("/coupons/#{t.id(:coupon_fixed)}", role: :admin)
t.assert_body("FIXED500 used_count=2", code, body, "used_count", 2)

# ══════════════════════════════════════════════
# SUMMARY
# ══════════════════════════════════════════════
exit t.summary
