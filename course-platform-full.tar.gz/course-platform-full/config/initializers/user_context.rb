require_relative "../../app/middleware/user_context"

Rails.application.config.middleware.use UserContext
