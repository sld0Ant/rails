Rails.application.routes.draw do
  get "up" => "rails/health#show", as: :rails_health_check

  endpoint OrganizationsEndpoint
  endpoint CategoriesEndpoint
  endpoint InstructorsEndpoint
  endpoint StudentsEndpoint
  endpoint CoursesEndpoint
  endpoint ModulesEndpoint, path: "modules"
  endpoint LessonsEndpoint
  endpoint EnrollmentsEndpoint
  endpoint LessonProgressesEndpoint
  endpoint ReviewsEndpoint
  endpoint CouponsEndpoint
  endpoint PaymentsEndpoint
  endpoint CertificatesEndpoint
  endpoint NotificationsEndpoint

  scope "notifications", format: :json do
    patch "/:id/mark_read", to: ->(env) {
      request = ActionDispatch::Request.new(env)
      path_params = env["action_dispatch.request.path_parameters"] || {}
      params = path_params.with_indifferent_access

      role = env["HTTP_X_USER_ROLE"].to_s
      unless %w[admin instructor student].include?(role)
        return [403, { "content-type" => "application/json" }, [{ error: "Forbidden" }.to_json]]
      end

      entity = NotificationsEndpoint.new.service.mark_read(params[:id])
      if entity.errors.any?
        [422, { "content-type" => "application/json" }, [{ errors: entity.errors.as_json }.to_json]]
      else
        [200, { "content-type" => "application/json" }, [entity.as_json.to_json]]
      end
    }
  end
end
