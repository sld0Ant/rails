#!/bin/bash


BASE="http://localhost:3000"
PASS=0
FAIL=0

check() {
  local step="$1"
  local expected="$2"
  local actual="$3"

  if echo "$actual" | grep -q "$expected"; then
    echo "✅ Step $step — PASS"
    PASS=$((PASS + 1))
  else
    echo "❌ Step $step — FAIL (expected '$expected')"
    echo "   Response: $actual"
    FAIL=$((FAIL + 1))
  fi
}

check_status() {
  local step="$1"
  local expected_code="$2"
  local actual_code="$3"
  local body="$4"

  if [ "$actual_code" = "$expected_code" ]; then
    echo "✅ Step $step — PASS (HTTP $actual_code)"
    PASS=$((PASS + 1))
  else
    echo "❌ Step $step — FAIL (expected HTTP $expected_code, got $actual_code)"
    echo "   Response: $body"
    FAIL=$((FAIL + 1))
  fi
}

post() {
  curl -s -g -w "\n%{http_code}" -X POST "$BASE$1" \
    -H "Content-Type: application/json" \
    -H "X-User-Role: $2" \
    -H "X-User-Id: ${3:-0}" \
    -d "$4"
}

patch() {
  curl -s -g -w "\n%{http_code}" -X PATCH "$BASE$1" \
    -H "Content-Type: application/json" \
    -H "X-User-Role: $2" \
    -H "X-User-Id: ${3:-0}" \
    -d "$4"
}

get() {
  curl -s -g -w "\n%{http_code}" -X GET "$BASE$1" \
    -H "X-User-Role: $2" \
    -H "X-User-Id: ${3:-0}"
}

echo "=== E2E Test: Course Platform ==="
echo ""

# Step 1: Admin creates Organization (pro plan), Category, Instructor, 2 Students
echo "--- Step 1: Admin setup ---"
R=$(post "/organizations" "admin" "0" '{"organization":{"name":"Acme School","slug":"acme","plan":"pro"}}')
BODY=$(echo "$R" | head -1)
CODE=$(echo "$R" | tail -1)
check_status "1a (org create)" "201" "$CODE" "$BODY"
ORG_ID=$(echo "$BODY" | ruby -rjson -e 'puts JSON.parse(STDIN.read)["id"]')
echo "   org_id=$ORG_ID"

# Verify plan limits auto-set
check "1a-limits" '"max_courses":50' "$BODY"

R=$(post "/categories" "admin" "0" '{"category":{"name":"Programming","slug":"programming","position":1}}')
BODY=$(echo "$R" | head -1)
CODE=$(echo "$R" | tail -1)
check_status "1b (category)" "201" "$CODE" "$BODY"
CAT_ID=$(echo "$BODY" | ruby -rjson -e 'puts JSON.parse(STDIN.read)["id"]')

R=$(post "/instructors" "admin" "0" "{\"instructor\":{\"organization_id\":$ORG_ID,\"name\":\"John Teacher\",\"email\":\"john@acme.com\"}}")
BODY=$(echo "$R" | head -1)
CODE=$(echo "$R" | tail -1)
check_status "1c (instructor)" "201" "$CODE" "$BODY"
INST_ID=$(echo "$BODY" | ruby -rjson -e 'puts JSON.parse(STDIN.read)["id"]')
echo "   instructor_id=$INST_ID"

R=$(post "/students" "admin" "0" "{\"student\":{\"organization_id\":$ORG_ID,\"name\":\"Alice Student\",\"email\":\"alice@example.com\"}}")
BODY=$(echo "$R" | head -1)
CODE=$(echo "$R" | tail -1)
check_status "1d (student1)" "201" "$CODE" "$BODY"
STU1_ID=$(echo "$BODY" | ruby -rjson -e 'puts JSON.parse(STDIN.read)["id"]')
echo "   student1_id=$STU1_ID"

R=$(post "/students" "admin" "0" "{\"student\":{\"organization_id\":$ORG_ID,\"name\":\"Bob Student\",\"email\":\"bob@example.com\"}}")
BODY=$(echo "$R" | head -1)
CODE=$(echo "$R" | tail -1)
check_status "1e (student2)" "201" "$CODE" "$BODY"
STU2_ID=$(echo "$BODY" | ruby -rjson -e 'puts JSON.parse(STDIN.read)["id"]')
echo "   student2_id=$STU2_ID"

echo ""
echo "--- Step 2: Instructor creates Course, 2 Modules, 3 Lessons each ---"
R=$(post "/courses" "instructor" "$INST_ID" "{\"course\":{\"organization_id\":$ORG_ID,\"category_id\":$CAT_ID,\"title\":\"Ruby Mastery\",\"price_cents\":5000,\"currency\":\"USD\"}}")
BODY=$(echo "$R" | head -1)
CODE=$(echo "$R" | tail -1)
check_status "2a (course)" "201" "$CODE" "$BODY"
COURSE_ID=$(echo "$BODY" | ruby -rjson -e 'puts JSON.parse(STDIN.read)["id"]')
echo "   course_id=$COURSE_ID"
check "2a-draft" '"status":"draft"' "$BODY"

R=$(post "/modules" "instructor" "$INST_ID" "{\"course_module\":{\"course_id\":$COURSE_ID,\"title\":\"Module 1\",\"position\":1}}")
BODY=$(echo "$R" | head -1)
CODE=$(echo "$R" | tail -1)
check_status "2b (module1)" "201" "$CODE" "$BODY"
MOD1_ID=$(echo "$BODY" | ruby -rjson -e 'puts JSON.parse(STDIN.read)["id"]')

R=$(post "/modules" "instructor" "$INST_ID" "{\"course_module\":{\"course_id\":$COURSE_ID,\"title\":\"Module 2\",\"position\":2}}")
BODY=$(echo "$R" | head -1)
CODE=$(echo "$R" | tail -1)
check_status "2c (module2)" "201" "$CODE" "$BODY"
MOD2_ID=$(echo "$BODY" | ruby -rjson -e 'puts JSON.parse(STDIN.read)["id"]')

LESSON_IDS=""
for i in 1 2 3; do
  R=$(post "/lessons" "instructor" "$INST_ID" "{\"lesson\":{\"module_id\":$MOD1_ID,\"title\":\"M1 Lesson $i\",\"position\":$i}}")
  BODY=$(echo "$R" | head -1)
  CODE=$(echo "$R" | tail -1)
  check_status "2d (m1-lesson$i)" "201" "$CODE" "$BODY"
  LID=$(echo "$BODY" | ruby -rjson -e 'puts JSON.parse(STDIN.read)["id"]')
  LESSON_IDS="$LESSON_IDS $LID"
done
for i in 1 2 3; do
  R=$(post "/lessons" "instructor" "$INST_ID" "{\"lesson\":{\"module_id\":$MOD2_ID,\"title\":\"M2 Lesson $i\",\"position\":$i}}")
  BODY=$(echo "$R" | head -1)
  CODE=$(echo "$R" | tail -1)
  check_status "2e (m2-lesson$i)" "201" "$CODE" "$BODY"
  LID=$(echo "$BODY" | ruby -rjson -e 'puts JSON.parse(STDIN.read)["id"]')
  LESSON_IDS="$LESSON_IDS $LID"
done

echo ""
echo "--- Step 3: Instructor tries publish without description ---"
R=$(post "/courses/$COURSE_ID/publish" "instructor" "$INST_ID" '{}')
BODY=$(echo "$R" | head -1)
CODE=$(echo "$R" | tail -1)
check_status "3 (publish fail)" "422" "$CODE" "$BODY"
check "3-error" "Description" "$BODY"

echo ""
echo "--- Step 4: Instructor updates description and publishes ---"
R=$(patch "/courses/$COURSE_ID" "instructor" "$INST_ID" '{"course":{"description":"Learn Ruby from scratch"}}')
BODY=$(echo "$R" | head -1)
CODE=$(echo "$R" | tail -1)
check_status "4a (update desc)" "200" "$CODE" "$BODY"

R=$(post "/courses/$COURSE_ID/publish" "instructor" "$INST_ID" '{}')
BODY=$(echo "$R" | head -1)
CODE=$(echo "$R" | tail -1)
check_status "4b (publish)" "200" "$CODE" "$BODY"
check "4b-published" '"status":"published"' "$BODY"

echo ""
echo "--- Step 5: Admin creates Coupon (20% off, max_uses: 5) ---"
R=$(post "/coupons" "admin" "0" '{"coupon":{"code":"SAVE20","discount_type":"percent","discount_value":20,"max_uses":5,"starts_at":"2025-01-01T00:00:00Z","expires_at":"2027-12-31T23:59:59Z"}}')
BODY=$(echo "$R" | head -1)
CODE=$(echo "$R" | tail -1)
check_status "5 (coupon)" "201" "$CODE" "$BODY"
COUPON_ID=$(echo "$BODY" | ruby -rjson -e 'puts JSON.parse(STDIN.read)["id"]')
echo "   coupon_id=$COUPON_ID"

echo ""
echo "--- Step 6: Student1 creates Enrollment ---"
R=$(post "/enrollments" "student" "$STU1_ID" "{\"enrollment\":{\"course_id\":$COURSE_ID}}")
BODY=$(echo "$R" | head -1)
CODE=$(echo "$R" | tail -1)
check_status "6 (enroll stu1)" "201" "$CODE" "$BODY"
ENROLL1_ID=$(echo "$BODY" | ruby -rjson -e 'puts JSON.parse(STDIN.read)["id"]')
echo "   enrollment1_id=$ENROLL1_ID"

# Check enrollments_count = 1
R=$(get "/courses/$COURSE_ID" "admin")
BODY=$(echo "$R" | head -1)
check "6-count" '"enrollments_count":1' "$BODY"

echo ""
echo "--- Step 7: Student1 creates Payment with coupon ---"
R=$(post "/payments" "student" "$STU1_ID" "{\"payment\":{\"enrollment_id\":$ENROLL1_ID,\"coupon_id\":$COUPON_ID}}")
BODY=$(echo "$R" | head -1)
CODE=$(echo "$R" | tail -1)
check_status "7a (payment)" "201" "$CODE" "$BODY"
PAY1_ID=$(echo "$BODY" | ruby -rjson -e 'puts JSON.parse(STDIN.read)["id"]')
check "7b (net)" '"net_amount_cents":4000' "$BODY"

# Check coupon used_count = 1
R=$(get "/coupons/$COUPON_ID" "admin")
BODY=$(echo "$R" | head -1)
check "7c (coupon used)" '"used_count":1' "$BODY"

echo ""
echo "--- Step 8: Admin confirms payment ---"
R=$(post "/payments/$PAY1_ID/confirm" "admin" "0" '{}')
BODY=$(echo "$R" | head -1)
CODE=$(echo "$R" | tail -1)
check_status "8a (confirm)" "200" "$CODE" "$BODY"
check "8b (paid_at)" '"paid_at"' "$BODY"

# Check notification was created
R=$(get "/notifications?filter[event_type]=payment&filter[student_id]=$STU1_ID" "admin")
BODY=$(echo "$R" | head -1)
check "8c (notification)" 'Payment confirmed' "$BODY"

echo ""
echo "--- Step 9: Student1 tries to cancel enrollment (should fail) ---"
R=$(post "/enrollments/$ENROLL1_ID/cancel" "student" "$STU1_ID" '{}')
BODY=$(echo "$R" | head -1)
CODE=$(echo "$R" | tail -1)
check_status "9 (cancel fail)" "422" "$CODE" "$BODY"
check "9-error" "Refund payment before cancelling" "$BODY"

echo ""
echo "--- Step 10: Admin refunds payment ---"
R=$(post "/payments/$PAY1_ID/refund" "admin" "0" '{}')
BODY=$(echo "$R" | head -1)
CODE=$(echo "$R" | tail -1)
check_status "10a (refund)" "200" "$CODE" "$BODY"
check "10b (refunded_at)" '"refunded_at"' "$BODY"

# Check coupon used_count = 0
R=$(get "/coupons/$COUPON_ID" "admin")
BODY=$(echo "$R" | head -1)
check "10c (coupon restored)" '"used_count":0' "$BODY"

echo ""
echo "--- Step 11: Student1 cancels enrollment ---"
R=$(post "/enrollments/$ENROLL1_ID/cancel" "student" "$STU1_ID" '{}')
BODY=$(echo "$R" | head -1)
CODE=$(echo "$R" | tail -1)
check_status "11a (cancel)" "200" "$CODE" "$BODY"

# Check enrollments_count = 0
R=$(get "/courses/$COURSE_ID" "admin")
BODY=$(echo "$R" | head -1)
check "11b (count=0)" '"enrollments_count":0' "$BODY"

echo ""
echo "--- Step 12: Student1 re-enrolls ---"
R=$(post "/enrollments" "student" "$STU1_ID" "{\"enrollment\":{\"course_id\":$COURSE_ID}}")
BODY=$(echo "$R" | head -1)
CODE=$(echo "$R" | tail -1)
check_status "12a (re-enroll)" "201" "$CODE" "$BODY"
ENROLL1B_ID=$(echo "$BODY" | ruby -rjson -e 'puts JSON.parse(STDIN.read)["id"]')

R=$(get "/courses/$COURSE_ID" "admin")
BODY=$(echo "$R" | head -1)
check "12b (count=1)" '"enrollments_count":1' "$BODY"

echo ""
echo "--- Step 13: Student2 creates Enrollment ---"
R=$(post "/enrollments" "student" "$STU2_ID" "{\"enrollment\":{\"course_id\":$COURSE_ID}}")
BODY=$(echo "$R" | head -1)
CODE=$(echo "$R" | tail -1)
check_status "13a (enroll stu2)" "201" "$CODE" "$BODY"
ENROLL2_ID=$(echo "$BODY" | ruby -rjson -e 'puts JSON.parse(STDIN.read)["id"]')

R=$(get "/courses/$COURSE_ID" "admin")
BODY=$(echo "$R" | head -1)
check "13b (count=2)" '"enrollments_count":2' "$BODY"

echo ""
echo "--- Step 14-15: Student2 completes all 6 lessons ---"
LESSON_ARR=($LESSON_IDS)
for i in "${!LESSON_ARR[@]}"; do
  LID=${LESSON_ARR[$i]}
  NUM=$((i + 1))

  # POST create (started)
  R=$(post "/lesson_progresses" "student" "$STU2_ID" "{\"lesson_progress\":{\"enrollment_id\":$ENROLL2_ID,\"lesson_id\":$LID}}")
  BODY=$(echo "$R" | head -1)
  CODE=$(echo "$R" | tail -1)
  check_status "14 (start L$NUM)" "201" "$CODE" "$BODY"
  LP_ID=$(echo "$BODY" | ruby -rjson -e 'puts JSON.parse(STDIN.read)["id"]')

  # PATCH update (completed)
  R=$(patch "/lesson_progresses/$LP_ID" "student" "$STU2_ID" '{"lesson_progress":{"status":"completed"}}')
  BODY=$(echo "$R" | head -1)
  CODE=$(echo "$R" | tail -1)
  check_status "14 (complete L$NUM)" "200" "$CODE" "$BODY"
done

# Check enrollment is completed with 100% progress
R=$(get "/enrollments/$ENROLL2_ID" "admin")
BODY=$(echo "$R" | head -1)
check "15a (progress 100)" '"progress_percent":100' "$BODY"
check "15b (completed)" '"status":"completed"' "$BODY"

# Check certificate was created
R=$(get "/certificates?filter[enrollment_id]=$ENROLL2_ID" "admin")
BODY=$(echo "$R" | head -1)
check "15c (certificate)" '"certificate_number"' "$BODY"

# Check certificate notification
R=$(get "/notifications?filter[event_type]=certificate&filter[student_id]=$STU2_ID" "admin")
BODY=$(echo "$R" | head -1)
check "15d (cert notif)" 'Certificate issued' "$BODY"

echo ""
echo "--- Step 16: Student2 tries to cancel completed enrollment ---"
R=$(post "/enrollments/$ENROLL2_ID/cancel" "student" "$STU2_ID" '{}')
BODY=$(echo "$R" | head -1)
CODE=$(echo "$R" | tail -1)
check_status "16 (cancel completed)" "422" "$CODE" "$BODY"

echo ""
echo "--- Step 17: Student2 creates Review (rating: 5) ---"
R=$(post "/reviews" "student" "$STU2_ID" "{\"review\":{\"course_id\":$COURSE_ID,\"rating\":5,\"body\":\"Excellent!\"}}")
BODY=$(echo "$R" | head -1)
CODE=$(echo "$R" | tail -1)
check_status "17a (review)" "201" "$CODE" "$BODY"

R=$(get "/courses/$COURSE_ID" "admin")
BODY=$(echo "$R" | head -1)
check "17b (avg rating)" '"average_rating"' "$BODY"

echo ""
echo "--- Step 18: Instructor archives course ---"
R=$(post "/courses/$COURSE_ID/archive" "instructor" "$INST_ID" '{}')
BODY=$(echo "$R" | head -1)
CODE=$(echo "$R" | tail -1)
check_status "18 (archive)" "200" "$CODE" "$BODY"
check "18-archived" '"status":"archived"' "$BODY"

echo ""
echo "--- Step 19: Try to enroll on archived course ---"
R=$(post "/enrollments" "student" "$STU1_ID" "{\"enrollment\":{\"course_id\":$COURSE_ID,\"student_id\":$STU1_ID}}")
BODY=$(echo "$R" | head -1)
CODE=$(echo "$R" | tail -1)
check_status "19 (archived enroll)" "422" "$CODE" "$BODY"
check "19-error" "not published" "$BODY"

echo ""
echo "--- Step 20: Free course flow ---"
R=$(post "/courses" "instructor" "$INST_ID" "{\"course\":{\"organization_id\":$ORG_ID,\"title\":\"Free Intro\",\"description\":\"Free intro\",\"price_cents\":0,\"currency\":\"USD\"}}")
BODY=$(echo "$R" | head -1)
CODE=$(echo "$R" | tail -1)
check_status "20a (free course)" "201" "$CODE" "$BODY"
COURSE2_ID=$(echo "$BODY" | ruby -rjson -e 'puts JSON.parse(STDIN.read)["id"]')

R=$(post "/modules" "instructor" "$INST_ID" "{\"course_module\":{\"course_id\":$COURSE2_ID,\"title\":\"Intro Module\",\"position\":1}}")
BODY=$(echo "$R" | head -1)
MOD3_ID=$(echo "$BODY" | ruby -rjson -e 'puts JSON.parse(STDIN.read)["id"]')

R=$(post "/lessons" "instructor" "$INST_ID" "{\"lesson\":{\"module_id\":$MOD3_ID,\"title\":\"Welcome\",\"position\":1}}")
BODY=$(echo "$R" | head -1)

R=$(post "/courses/$COURSE2_ID/publish" "instructor" "$INST_ID" '{}')
BODY=$(echo "$R" | head -1)
CODE=$(echo "$R" | tail -1)
check_status "20b (publish free)" "200" "$CODE" "$BODY"

echo ""
echo "--- Step 21: Student1 enrolls in free course ---"
R=$(post "/enrollments" "student" "$STU1_ID" "{\"enrollment\":{\"course_id\":$COURSE2_ID}}")
BODY=$(echo "$R" | head -1)
CODE=$(echo "$R" | tail -1)
check_status "21 (enroll free)" "201" "$CODE" "$BODY"
ENROLL3_ID=$(echo "$BODY" | ruby -rjson -e 'puts JSON.parse(STDIN.read)["id"]')

echo ""
echo "--- Step 22: Student1 tries to create Payment on free course ---"
R=$(post "/payments" "student" "$STU1_ID" "{\"payment\":{\"enrollment_id\":$ENROLL3_ID}}")
BODY=$(echo "$R" | head -1)
CODE=$(echo "$R" | tail -1)
check_status "22 (pay free fail)" "422" "$CODE" "$BODY"
check "22-error" "Course is free" "$BODY"

echo ""
echo "=== Results: $PASS passed, $FAIL failed ==="
