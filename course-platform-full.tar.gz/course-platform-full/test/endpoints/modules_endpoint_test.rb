require "test_helper"

class ModulesEndpointTest < ActionDispatch::IntegrationTest
  test "index returns success" do
    get "/modules", as: :json
    assert_response :success
  end

  test "show returns not found for missing id" do
    get "/modules/999999", as: :json
    assert_response :not_found
  end

  test "create returns created" do
    post "/modules", params: { module: { title: "test", position: 1 } }, as: :json
    assert_response :created
  end
end
