require "test_helper"

class NotificationsEndpointTest < ActionDispatch::IntegrationTest
  test "index returns success" do
    get "/notifications", as: :json
    assert_response :success
  end

  test "show returns not found for missing id" do
    get "/notifications/999999", as: :json
    assert_response :not_found
  end

  test "create returns created" do
    post "/notifications", params: { notification: { event_type: "test", title: "test", body: "test", read_at: "test" } }, as: :json
    assert_response :created
  end
end
