require "test_helper"

class LessonProgressesEndpointTest < ActionDispatch::IntegrationTest
  test "index returns success" do
    get "/lesson_progresses", as: :json
    assert_response :success
  end

  test "show returns not found for missing id" do
    get "/lesson_progresses/999999", as: :json
    assert_response :not_found
  end

  test "create returns created" do
    post "/lesson_progresses", params: { lesson_progress: { status: "test", started_at: "test", completed_at: "test" } }, as: :json
    assert_response :created
  end
end
