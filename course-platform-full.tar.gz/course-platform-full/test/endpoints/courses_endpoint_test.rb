require "test_helper"

class CoursesEndpointTest < ActionDispatch::IntegrationTest
  test "index returns success" do
    get "/courses", as: :json
    assert_response :success
  end

  test "show returns not found for missing id" do
    get "/courses/999999", as: :json
    assert_response :not_found
  end

  test "create returns created" do
    post "/courses", params: { course: { title: "test", description: "test", price_cents: 1, currency: "test", max_students: 1, enrollments_count: 1, average_rating: 1.0, status: "test", published_at: "test" } }, as: :json
    assert_response :created
  end
end
