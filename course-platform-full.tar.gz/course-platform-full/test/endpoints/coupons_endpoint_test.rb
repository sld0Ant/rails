require "test_helper"

class CouponsEndpointTest < ActionDispatch::IntegrationTest
  test "index returns success" do
    get "/coupons", as: :json
    assert_response :success
  end

  test "show returns not found for missing id" do
    get "/coupons/999999", as: :json
    assert_response :not_found
  end

  test "create returns created" do
    post "/coupons", params: { coupon: { code: "test", discount_type: "test", discount_value: 1, currency: "test", min_purchase_cents: 1, max_uses: 1, used_count: 1, starts_at: "test", expires_at: "test", active: true } }, as: :json
    assert_response :created
  end
end
