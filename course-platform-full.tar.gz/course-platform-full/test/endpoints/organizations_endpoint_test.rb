require "test_helper"

class OrganizationsEndpointTest < ActionDispatch::IntegrationTest
  test "index returns success" do
    get "/organizations", as: :json
    assert_response :success
  end

  test "show returns not found for missing id" do
    get "/organizations/999999", as: :json
    assert_response :not_found
  end

  test "create returns created" do
    post "/organizations", params: { organization: { name: "test", slug: "test", plan: "test", max_courses: 1, max_students: 1, logo_url: "test" } }, as: :json
    assert_response :created
  end
end
