require "test_helper"

class LessonsEndpointTest < ActionDispatch::IntegrationTest
  test "index returns success" do
    get "/lessons", as: :json
    assert_response :success
  end

  test "show returns not found for missing id" do
    get "/lessons/999999", as: :json
    assert_response :not_found
  end

  test "create returns created" do
    post "/lessons", params: { lesson: { title: "test", content: "test", lesson_type: "test", video_url: "test", position: 1, duration_minutes: 1 } }, as: :json
    assert_response :created
  end
end
