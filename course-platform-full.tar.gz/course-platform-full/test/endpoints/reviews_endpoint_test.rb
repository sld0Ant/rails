require "test_helper"

class ReviewsEndpointTest < ActionDispatch::IntegrationTest
  test "index returns success" do
    get "/reviews", as: :json
    assert_response :success
  end

  test "show returns not found for missing id" do
    get "/reviews/999999", as: :json
    assert_response :not_found
  end

  test "create returns created" do
    post "/reviews", params: { review: { rating: 1, body: "test" } }, as: :json
    assert_response :created
  end
end
