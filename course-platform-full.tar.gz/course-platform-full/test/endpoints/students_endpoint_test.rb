require "test_helper"

class StudentsEndpointTest < ActionDispatch::IntegrationTest
  test "index returns success" do
    get "/students", as: :json
    assert_response :success
  end

  test "show returns not found for missing id" do
    get "/students/999999", as: :json
    assert_response :not_found
  end

  test "create returns created" do
    post "/students", params: { student: { name: "test", email: "test", avatar_url: "test" } }, as: :json
    assert_response :created
  end
end
