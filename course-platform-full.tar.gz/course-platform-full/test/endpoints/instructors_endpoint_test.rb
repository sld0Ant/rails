require "test_helper"

class InstructorsEndpointTest < ActionDispatch::IntegrationTest
  test "index returns success" do
    get "/instructors", as: :json
    assert_response :success
  end

  test "show returns not found for missing id" do
    get "/instructors/999999", as: :json
    assert_response :not_found
  end

  test "create returns created" do
    post "/instructors", params: { instructor: { name: "test", email: "test", bio: "test", avatar_url: "test" } }, as: :json
    assert_response :created
  end
end
