require "test_helper"

class CategoriesEndpointTest < ActionDispatch::IntegrationTest
  test "index returns success" do
    get "/categories", as: :json
    assert_response :success
  end

  test "show returns not found for missing id" do
    get "/categories/999999", as: :json
    assert_response :not_found
  end

  test "create returns created" do
    post "/categories", params: { category: { name: "test", slug: "test", position: 1 } }, as: :json
    assert_response :created
  end
end
