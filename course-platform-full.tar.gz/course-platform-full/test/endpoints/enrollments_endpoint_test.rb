require "test_helper"

class EnrollmentsEndpointTest < ActionDispatch::IntegrationTest
  test "index returns success" do
    get "/enrollments", as: :json
    assert_response :success
  end

  test "show returns not found for missing id" do
    get "/enrollments/999999", as: :json
    assert_response :not_found
  end

  test "create returns created" do
    post "/enrollments", params: { enrollment: { status: "test", progress_percent: 1, enrolled_at: "test", completed_at: "test" } }, as: :json
    assert_response :created
  end
end
