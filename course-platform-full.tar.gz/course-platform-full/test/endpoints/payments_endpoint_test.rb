require "test_helper"

class PaymentsEndpointTest < ActionDispatch::IntegrationTest
  test "index returns success" do
    get "/payments", as: :json
    assert_response :success
  end

  test "show returns not found for missing id" do
    get "/payments/999999", as: :json
    assert_response :not_found
  end

  test "create returns created" do
    post "/payments", params: { payment: { amount_cents: 1, net_amount_cents: 1, currency: "test", status: "test", paid_at: "test", refunded_at: "test" } }, as: :json
    assert_response :created
  end
end
