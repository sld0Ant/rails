require "test_helper"

class CertificatesEndpointTest < ActionDispatch::IntegrationTest
  test "index returns success" do
    get "/certificates", as: :json
    assert_response :success
  end

  test "show returns not found for missing id" do
    get "/certificates/999999", as: :json
    assert_response :not_found
  end

  test "create returns created" do
    post "/certificates", params: { certificate: { certificate_number: "test", issued_at: "test" } }, as: :json
    assert_response :created
  end
end
