require "test_helper"

class ReviewRepositoryTest < ActiveSupport::TestCase
  def setup
    @repository = ReviewRepository.new
  end

  test "record_class is set" do
    assert_equal ReviewRecord, @repository.class.record_class
  end

  test "entity_class is set" do
    assert_equal Review, @repository.class.entity_class
  end

  test "responds to all" do
    assert_respond_to @repository, :all
  end

  test "responds to find" do
    assert_respond_to @repository, :find
  end

  test "responds to create" do
    assert_respond_to @repository, :create
  end

  test "responds to paginate" do
    assert_respond_to @repository, :paginate
  end
end
