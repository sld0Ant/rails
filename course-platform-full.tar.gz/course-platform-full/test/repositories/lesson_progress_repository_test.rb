require "test_helper"

class LessonProgressRepositoryTest < ActiveSupport::TestCase
  def setup
    @repository = LessonProgressRepository.new
  end

  test "record_class is set" do
    assert_equal LessonProgressRecord, @repository.class.record_class
  end

  test "entity_class is set" do
    assert_equal LessonProgress, @repository.class.entity_class
  end

  test "responds to all" do
    assert_respond_to @repository, :all
  end

  test "responds to find" do
    assert_respond_to @repository, :find
  end

  test "responds to create" do
    assert_respond_to @repository, :create
  end

  test "responds to paginate" do
    assert_respond_to @repository, :paginate
  end
end
