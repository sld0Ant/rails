require "test_helper"

class PaymentTest < ActiveSupport::TestCase
  test "creates entity with attributes" do
    entity = Payment.new(enrollment_id: 1, coupon_id: 1, amount_cents: 1, net_amount_cents: 1, currency: "test", status: "test", paid_at: "test", refunded_at: "test")
    assert_not_nil entity.enrollment_id
    assert_not_nil entity.coupon_id
  end

  test "not persisted without id" do
    entity = Payment.new
    assert_not entity.persisted?
  end

  test "persisted with id" do
    entity = Payment.new(id: 1)
    assert entity.persisted?
  end
end
