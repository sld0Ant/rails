require "test_helper"

class CategoryTest < ActiveSupport::TestCase
  test "creates entity with attributes" do
    entity = Category.new(parent_id: 1, name: "test", slug: "test", position: 1)
    assert_not_nil entity.parent_id
    assert_not_nil entity.name
  end

  test "not persisted without id" do
    entity = Category.new
    assert_not entity.persisted?
  end

  test "persisted with id" do
    entity = Category.new(id: 1)
    assert entity.persisted?
  end
end
