require "test_helper"

class CouponTest < ActiveSupport::TestCase
  test "creates entity with attributes" do
    entity = Coupon.new(code: "test", discount_type: "test", discount_value: 1, currency: "test", min_purchase_cents: 1, max_uses: 1, used_count: 1, starts_at: "test", expires_at: "test", active: true)
    assert_not_nil entity.code
    assert_not_nil entity.discount_type
  end

  test "not persisted without id" do
    entity = Coupon.new
    assert_not entity.persisted?
  end

  test "persisted with id" do
    entity = Coupon.new(id: 1)
    assert entity.persisted?
  end
end
