require "test_helper"

class InstructorTest < ActiveSupport::TestCase
  test "creates entity with attributes" do
    entity = Instructor.new(organization_id: 1, name: "test", email: "test", bio: "test", avatar_url: "test")
    assert_not_nil entity.organization_id
    assert_not_nil entity.name
  end

  test "not persisted without id" do
    entity = Instructor.new
    assert_not entity.persisted?
  end

  test "persisted with id" do
    entity = Instructor.new(id: 1)
    assert entity.persisted?
  end
end
