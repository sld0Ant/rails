require "test_helper"

class LessonProgressTest < ActiveSupport::TestCase
  test "creates entity with attributes" do
    entity = LessonProgress.new(enrollment_id: 1, lesson_id: 1, status: "test", started_at: "test", completed_at: "test")
    assert_not_nil entity.enrollment_id
    assert_not_nil entity.lesson_id
  end

  test "not persisted without id" do
    entity = LessonProgress.new
    assert_not entity.persisted?
  end

  test "persisted with id" do
    entity = LessonProgress.new(id: 1)
    assert entity.persisted?
  end
end
