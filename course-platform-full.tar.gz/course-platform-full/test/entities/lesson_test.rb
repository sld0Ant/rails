require "test_helper"

class LessonTest < ActiveSupport::TestCase
  test "creates entity with attributes" do
    entity = Lesson.new(module_id: 1, title: "test", content: "test", lesson_type: "test", video_url: "test", position: 1, duration_minutes: 1)
    assert_not_nil entity.module_id
    assert_not_nil entity.title
  end

  test "not persisted without id" do
    entity = Lesson.new
    assert_not entity.persisted?
  end

  test "persisted with id" do
    entity = Lesson.new(id: 1)
    assert entity.persisted?
  end
end
