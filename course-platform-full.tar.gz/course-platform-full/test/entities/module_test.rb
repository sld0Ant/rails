require "test_helper"

class ModuleTest < ActiveSupport::TestCase
  test "creates entity with attributes" do
    entity = Module.new(course_id: 1, title: "test", position: 1)
    assert_not_nil entity.course_id
    assert_not_nil entity.title
  end

  test "not persisted without id" do
    entity = Module.new
    assert_not entity.persisted?
  end

  test "persisted with id" do
    entity = Module.new(id: 1)
    assert entity.persisted?
  end
end
