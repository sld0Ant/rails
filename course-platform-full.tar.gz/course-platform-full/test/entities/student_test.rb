require "test_helper"

class StudentTest < ActiveSupport::TestCase
  test "creates entity with attributes" do
    entity = Student.new(organization_id: 1, name: "test", email: "test", avatar_url: "test")
    assert_not_nil entity.organization_id
    assert_not_nil entity.name
  end

  test "not persisted without id" do
    entity = Student.new
    assert_not entity.persisted?
  end

  test "persisted with id" do
    entity = Student.new(id: 1)
    assert entity.persisted?
  end
end
