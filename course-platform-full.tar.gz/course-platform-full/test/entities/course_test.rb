require "test_helper"

class CourseTest < ActiveSupport::TestCase
  test "creates entity with attributes" do
    entity = Course.new(organization_id: 1, instructor_id: 1, category_id: 1, title: "test", description: "test", price_cents: 1, currency: "test", max_students: 1, enrollments_count: 1, average_rating: "test", status: "test", published_at: "test")
    assert_not_nil entity.organization_id
    assert_not_nil entity.instructor_id
  end

  test "not persisted without id" do
    entity = Course.new
    assert_not entity.persisted?
  end

  test "persisted with id" do
    entity = Course.new(id: 1)
    assert entity.persisted?
  end
end
