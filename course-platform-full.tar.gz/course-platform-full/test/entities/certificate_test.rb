require "test_helper"

class CertificateTest < ActiveSupport::TestCase
  test "creates entity with attributes" do
    entity = Certificate.new(enrollment_id: 1, certificate_number: "test", issued_at: "test")
    assert_not_nil entity.enrollment_id
    assert_not_nil entity.certificate_number
  end

  test "not persisted without id" do
    entity = Certificate.new
    assert_not entity.persisted?
  end

  test "persisted with id" do
    entity = Certificate.new(id: 1)
    assert entity.persisted?
  end
end
