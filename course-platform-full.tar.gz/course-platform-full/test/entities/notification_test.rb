require "test_helper"

class NotificationTest < ActiveSupport::TestCase
  test "creates entity with attributes" do
    entity = Notification.new(student_id: 1, instructor_id: 1, event_type: "test", title: "test", body: "test", read_at: "test")
    assert_not_nil entity.student_id
    assert_not_nil entity.instructor_id
  end

  test "not persisted without id" do
    entity = Notification.new
    assert_not entity.persisted?
  end

  test "persisted with id" do
    entity = Notification.new(id: 1)
    assert entity.persisted?
  end
end
