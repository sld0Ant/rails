require "test_helper"

class EnrollmentTest < ActiveSupport::TestCase
  test "creates entity with attributes" do
    entity = Enrollment.new(course_id: 1, student_id: 1, status: "test", progress_percent: 1, enrolled_at: "test", completed_at: "test")
    assert_not_nil entity.course_id
    assert_not_nil entity.student_id
  end

  test "not persisted without id" do
    entity = Enrollment.new
    assert_not entity.persisted?
  end

  test "persisted with id" do
    entity = Enrollment.new(id: 1)
    assert entity.persisted?
  end
end
