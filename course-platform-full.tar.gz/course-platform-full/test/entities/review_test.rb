require "test_helper"

class ReviewTest < ActiveSupport::TestCase
  test "creates entity with attributes" do
    entity = Review.new(course_id: 1, student_id: 1, rating: 1, body: "test")
    assert_not_nil entity.course_id
    assert_not_nil entity.student_id
  end

  test "not persisted without id" do
    entity = Review.new
    assert_not entity.persisted?
  end

  test "persisted with id" do
    entity = Review.new(id: 1)
    assert entity.persisted?
  end
end
