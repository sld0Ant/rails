require "test_helper"

class OrganizationTest < ActiveSupport::TestCase
  test "creates entity with attributes" do
    entity = Organization.new(name: "test", slug: "test", plan: "test", max_courses: 1, max_students: 1, logo_url: "test")
    assert_not_nil entity.name
    assert_not_nil entity.slug
  end

  test "not persisted without id" do
    entity = Organization.new
    assert_not entity.persisted?
  end

  test "persisted with id" do
    entity = Organization.new(id: 1)
    assert entity.persisted?
  end
end
