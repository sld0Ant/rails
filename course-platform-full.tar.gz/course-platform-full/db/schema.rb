# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# This file is the source Rails uses to define your schema when running `bin/rails
# db:schema:load`. When creating a new database, `bin/rails db:schema:load` tends to
# be faster and is potentially less error prone than running all of your
# migrations from scratch. Old migrations may fail to apply correctly if those
# migrations use external dependencies or application code.
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema[8.2].define(version: 2026_03_20_093428) do
  create_table "categories", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.string "name", null: false
    t.integer "parent_id"
    t.integer "position", default: 0, null: false
    t.string "slug", null: false
    t.datetime "updated_at", null: false
    t.index ["parent_id"], name: "index_categories_on_parent_id"
  end

  create_table "certificates", force: :cascade do |t|
    t.string "certificate_number", null: false
    t.datetime "created_at", null: false
    t.integer "enrollment_id", null: false
    t.datetime "issued_at", null: false
    t.datetime "updated_at", null: false
    t.index ["certificate_number"], name: "index_certificates_on_certificate_number", unique: true
    t.index ["enrollment_id"], name: "index_certificates_on_enrollment_id"
  end

  create_table "coupons", force: :cascade do |t|
    t.boolean "active", default: true, null: false
    t.string "code", null: false
    t.datetime "created_at", null: false
    t.string "currency"
    t.string "discount_type", null: false
    t.integer "discount_value", null: false
    t.datetime "expires_at", null: false
    t.integer "max_uses"
    t.integer "min_purchase_cents"
    t.datetime "starts_at", null: false
    t.datetime "updated_at", null: false
    t.integer "used_count", default: 0, null: false
    t.index ["code"], name: "index_coupons_on_code", unique: true
  end

  create_table "courses", force: :cascade do |t|
    t.decimal "average_rating", precision: 3, scale: 2
    t.integer "category_id"
    t.datetime "created_at", null: false
    t.string "currency", default: "USD", null: false
    t.text "description"
    t.integer "enrollments_count", default: 0, null: false
    t.integer "instructor_id", null: false
    t.integer "max_students"
    t.integer "organization_id", null: false
    t.integer "price_cents", default: 0, null: false
    t.datetime "published_at"
    t.string "status", default: "draft", null: false
    t.string "title", null: false
    t.datetime "updated_at", null: false
    t.index ["category_id"], name: "index_courses_on_category_id"
    t.index ["instructor_id"], name: "index_courses_on_instructor_id"
    t.index ["organization_id"], name: "index_courses_on_organization_id"
  end

  create_table "enrollments", force: :cascade do |t|
    t.datetime "completed_at"
    t.integer "course_id", null: false
    t.datetime "created_at", null: false
    t.datetime "enrolled_at"
    t.integer "progress_percent", default: 0, null: false
    t.string "status", default: "active", null: false
    t.integer "student_id", null: false
    t.datetime "updated_at", null: false
    t.index ["course_id"], name: "index_enrollments_on_course_id"
    t.index ["student_id"], name: "index_enrollments_on_student_id"
  end

  create_table "instructors", force: :cascade do |t|
    t.string "avatar_url"
    t.text "bio"
    t.datetime "created_at", null: false
    t.string "email", null: false
    t.string "name", null: false
    t.integer "organization_id", null: false
    t.datetime "updated_at", null: false
    t.index ["organization_id"], name: "index_instructors_on_organization_id"
  end

  create_table "lesson_progresses", force: :cascade do |t|
    t.datetime "completed_at"
    t.datetime "created_at", null: false
    t.integer "enrollment_id", null: false
    t.integer "lesson_id", null: false
    t.datetime "started_at"
    t.string "status", default: "not_started", null: false
    t.datetime "updated_at", null: false
    t.index ["enrollment_id", "lesson_id"], name: "index_lesson_progresses_on_enrollment_id_and_lesson_id", unique: true
    t.index ["enrollment_id"], name: "index_lesson_progresses_on_enrollment_id"
    t.index ["lesson_id"], name: "index_lesson_progresses_on_lesson_id"
  end

  create_table "lessons", force: :cascade do |t|
    t.text "content"
    t.datetime "created_at", null: false
    t.integer "duration_minutes"
    t.string "lesson_type", default: "text", null: false
    t.integer "module_id", null: false
    t.integer "position", default: 1, null: false
    t.string "title", null: false
    t.datetime "updated_at", null: false
    t.string "video_url"
    t.index ["module_id"], name: "index_lessons_on_module_id"
  end

  create_table "modules", force: :cascade do |t|
    t.integer "course_id", null: false
    t.datetime "created_at", null: false
    t.integer "position", default: 1, null: false
    t.string "title", null: false
    t.datetime "updated_at", null: false
    t.index ["course_id"], name: "index_modules_on_course_id"
  end

  create_table "notifications", force: :cascade do |t|
    t.text "body"
    t.datetime "created_at", null: false
    t.string "event_type", null: false
    t.integer "instructor_id"
    t.datetime "read_at"
    t.integer "student_id"
    t.string "title", null: false
    t.datetime "updated_at", null: false
    t.index ["instructor_id"], name: "index_notifications_on_instructor_id"
    t.index ["student_id"], name: "index_notifications_on_student_id"
  end

  create_table "organizations", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.string "logo_url"
    t.integer "max_courses"
    t.integer "max_students"
    t.string "name", null: false
    t.string "plan", default: "free", null: false
    t.string "slug", null: false
    t.datetime "updated_at", null: false
    t.index ["slug"], name: "index_organizations_on_slug", unique: true
  end

  create_table "payments", force: :cascade do |t|
    t.integer "amount_cents", null: false
    t.integer "coupon_id"
    t.datetime "created_at", null: false
    t.string "currency", null: false
    t.integer "enrollment_id", null: false
    t.integer "net_amount_cents", null: false
    t.datetime "paid_at"
    t.datetime "refunded_at"
    t.string "status", default: "pending", null: false
    t.datetime "updated_at", null: false
    t.index ["coupon_id"], name: "index_payments_on_coupon_id"
    t.index ["enrollment_id"], name: "index_payments_on_enrollment_id"
  end

  create_table "reviews", force: :cascade do |t|
    t.text "body"
    t.integer "course_id", null: false
    t.datetime "created_at", null: false
    t.integer "rating", null: false
    t.integer "student_id", null: false
    t.datetime "updated_at", null: false
    t.index ["course_id", "student_id"], name: "index_reviews_on_course_id_and_student_id", unique: true
    t.index ["course_id"], name: "index_reviews_on_course_id"
    t.index ["student_id"], name: "index_reviews_on_student_id"
  end

  create_table "students", force: :cascade do |t|
    t.string "avatar_url"
    t.datetime "created_at", null: false
    t.string "email", null: false
    t.string "name", null: false
    t.integer "organization_id", null: false
    t.datetime "updated_at", null: false
    t.index ["organization_id"], name: "index_students_on_organization_id"
  end

  add_foreign_key "categories", "categories", column: "parent_id"
  add_foreign_key "certificates", "enrollments"
  add_foreign_key "courses", "categories", on_delete: :nullify
  add_foreign_key "courses", "instructors"
  add_foreign_key "courses", "organizations"
  add_foreign_key "enrollments", "courses"
  add_foreign_key "enrollments", "students"
  add_foreign_key "instructors", "organizations"
  add_foreign_key "lesson_progresses", "enrollments"
  add_foreign_key "lesson_progresses", "lessons"
  add_foreign_key "lessons", "modules"
  add_foreign_key "modules", "courses"
  add_foreign_key "notifications", "instructors"
  add_foreign_key "notifications", "students"
  add_foreign_key "payments", "coupons"
  add_foreign_key "payments", "enrollments"
  add_foreign_key "reviews", "courses"
  add_foreign_key "reviews", "students"
  add_foreign_key "students", "organizations"
end
