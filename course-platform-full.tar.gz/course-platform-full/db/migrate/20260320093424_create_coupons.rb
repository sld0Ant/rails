class CreateCoupons < ActiveRecord::Migration[8.2]
  def change
    create_table :coupons do |t|
      t.string :code, null: false
      t.string :discount_type, null: false
      t.integer :discount_value, null: false
      t.string :currency
      t.integer :min_purchase_cents
      t.integer :max_uses
      t.integer :used_count, null: false, default: 0
      t.datetime :starts_at, null: false
      t.datetime :expires_at, null: false
      t.boolean :active, null: false, default: true

      t.timestamps
    end

    add_index :coupons, :code, unique: true
  end
end
