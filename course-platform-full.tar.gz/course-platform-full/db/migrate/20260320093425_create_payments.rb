class CreatePayments < ActiveRecord::Migration[8.2]
  def change
    create_table :payments do |t|
      t.references :enrollment, null: false, foreign_key: true
      t.references :coupon, foreign_key: true
      t.integer :amount_cents, null: false
      t.integer :net_amount_cents, null: false
      t.string :currency, null: false
      t.string :status, null: false, default: "pending"
      t.datetime :paid_at
      t.datetime :refunded_at

      t.timestamps
    end
  end
end
