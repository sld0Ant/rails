class CreateEnrollments < ActiveRecord::Migration[8.2]
  def change
    create_table :enrollments do |t|
      t.references :course, null: false, foreign_key: true
      t.references :student, null: false, foreign_key: true
      t.string :status, null: false, default: "active"
      t.integer :progress_percent, null: false, default: 0
      t.datetime :enrolled_at
      t.datetime :completed_at

      t.timestamps
    end
  end
end
