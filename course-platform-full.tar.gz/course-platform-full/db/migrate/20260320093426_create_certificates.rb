class CreateCertificates < ActiveRecord::Migration[8.2]
  def change
    create_table :certificates do |t|
      t.references :enrollment, null: false, foreign_key: true
      t.string :certificate_number, null: false
      t.datetime :issued_at, null: false

      t.timestamps
    end

    add_index :certificates, :certificate_number, unique: true
  end
end
