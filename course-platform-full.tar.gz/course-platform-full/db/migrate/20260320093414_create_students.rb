class CreateStudents < ActiveRecord::Migration[8.2]
  def change
    create_table :students do |t|
      t.references :organization, null: false, foreign_key: true
      t.string :name, null: false
      t.string :email, null: false
      t.string :avatar_url

      t.timestamps
    end
  end
end
