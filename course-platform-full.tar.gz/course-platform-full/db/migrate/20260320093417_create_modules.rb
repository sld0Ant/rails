class CreateModules < ActiveRecord::Migration[8.2]
  def change
    create_table :modules do |t|
      t.references :course, null: false, foreign_key: true
      t.string :title, null: false
      t.integer :position, null: false, default: 1

      t.timestamps
    end
  end
end
