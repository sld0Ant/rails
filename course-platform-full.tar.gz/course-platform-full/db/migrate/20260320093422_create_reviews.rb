class CreateReviews < ActiveRecord::Migration[8.2]
  def change
    create_table :reviews do |t|
      t.references :course, null: false, foreign_key: true
      t.references :student, null: false, foreign_key: true
      t.integer :rating, null: false
      t.text :body

      t.timestamps
    end

    add_index :reviews, [:course_id, :student_id], unique: true
  end
end
