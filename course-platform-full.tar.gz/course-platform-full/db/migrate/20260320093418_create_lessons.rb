class CreateLessons < ActiveRecord::Migration[8.2]
  def change
    create_table :lessons do |t|
      t.references :module, null: false, foreign_key: true
      t.string :title, null: false
      t.text :content
      t.string :lesson_type, null: false, default: "text"
      t.string :video_url
      t.integer :position, null: false, default: 1
      t.integer :duration_minutes

      t.timestamps
    end
  end
end
