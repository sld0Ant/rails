class CreateCourses < ActiveRecord::Migration[8.2]
  def change
    create_table :courses do |t|
      t.references :organization, null: false, foreign_key: true
      t.references :instructor, null: false, foreign_key: true
      t.references :category, foreign_key: { on_delete: :nullify }
      t.string :title, null: false
      t.text :description
      t.integer :price_cents, null: false, default: 0
      t.string :currency, null: false, default: "USD"
      t.integer :max_students
      t.integer :enrollments_count, null: false, default: 0
      t.decimal :average_rating, precision: 3, scale: 2
      t.string :status, null: false, default: "draft"
      t.datetime :published_at

      t.timestamps
    end
  end
end
