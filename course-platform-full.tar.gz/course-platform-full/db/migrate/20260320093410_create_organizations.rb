class CreateOrganizations < ActiveRecord::Migration[8.2]
  def change
    create_table :organizations do |t|
      t.string :name, null: false
      t.string :slug, null: false
      t.string :plan, null: false, default: "free"
      t.integer :max_courses
      t.integer :max_students
      t.string :logo_url

      t.timestamps
    end

    add_index :organizations, :slug, unique: true
  end
end
