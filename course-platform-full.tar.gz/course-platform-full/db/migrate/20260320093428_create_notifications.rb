class CreateNotifications < ActiveRecord::Migration[8.2]
  def change
    create_table :notifications do |t|
      t.references :student, foreign_key: true
      t.references :instructor, foreign_key: true
      t.string :event_type, null: false
      t.string :title, null: false
      t.text :body
      t.datetime :read_at

      t.timestamps
    end
  end
end
